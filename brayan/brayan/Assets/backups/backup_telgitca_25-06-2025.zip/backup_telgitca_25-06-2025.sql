SET FOREIGN_KEY_CHECKS=0;

CREATE DATABASE IF NOT EXISTS wisp_juan;

USE wisp_juan;

DROP TABLE IF EXISTS ap_clientes;

CREATE TABLE `ap_clientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ip` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `version` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `vencido` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO ap_clientes VALUES("1","UBIQUITI LITE BEAM M5","192.168.50.1","XW.v6.2.0","");
INSERT INTO ap_clientes VALUES("2","UBIQUITI LITE BEAM M5 GEN2","192.168.50.1","WA.v8.7.11","");
INSERT INTO ap_clientes VALUES("3","CABLE RJ-45 LAN","192.168.50.1","1.1","");
INSERT INTO ap_clientes VALUES("4","MIKROTIK SXT","192.168.50.1","6.49.18","");
INSERT INTO ap_clientes VALUES("5","UBIQUITI NANO LOCA M2","192.168.50.1","XM.v6.1.7","");



DROP TABLE IF EXISTS ap_emisor;

CREATE TABLE `ap_emisor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ip` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `version` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO ap_emisor VALUES("1","UBIQUITI ROCKET PRISMA GEN2  120° 19-DBI","192.168.50.1","1.1");
INSERT INTO ap_emisor VALUES("2","MIKROTIK MANTBOX  120° 12-15s dbi","192.168.50.4","6.49.18");
INSERT INTO ap_emisor VALUES("3","UBIQUITI NANO LOCA M2","192.168.50.1","XM.v6.1.7");



DROP TABLE IF EXISTS ap_receptor;

CREATE TABLE `ap_receptor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci NOT NULL,
  `ip` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `version` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO ap_receptor VALUES("1","Ubiquiti Lite Beam M5 Gen-2","192.168.50.88","WA.v8.7.11");



DROP TABLE IF EXISTS archivos;

CREATE TABLE `archivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` int NOT NULL,
  `ruta` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tabla` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




DROP TABLE IF EXISTS backups;

CREATE TABLE `backups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `archive` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `size` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS bills;

CREATE TABLE `bills` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userid` bigint NOT NULL,
  `clientid` bigint NOT NULL,
  `voucherid` bigint NOT NULL,
  `serieid` bigint NOT NULL,
  `internal_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `correlative` bigint NOT NULL,
  `date_issue` date NOT NULL,
  `expiration_date` date NOT NULL,
  `billed_month` date NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `discount` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL,
  `remaining_amount` decimal(12,2) NOT NULL,
  `type` bigint NOT NULL,
  `sales_method` bigint NOT NULL,
  `observation` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `promise_enabled` tinyint NOT NULL,
  `promise_date` date DEFAULT NULL,
  `promise_set_date` date DEFAULT NULL,
  `promise_comment` varchar(512) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint NOT NULL DEFAULT '2',
  `compromise_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `serviceid` (`clientid`),
  KEY `userid` (`userid`),
  KEY `voucherid` (`voucherid`),
  KEY `serieid` (`serieid`),
  CONSTRAINT `bills_ibfk_3` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bills_ibfk_5` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bills_ibfk_6` FOREIGN KEY (`voucherid`) REFERENCES `vouchers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bills_ibfk_7` FOREIGN KEY (`serieid`) REFERENCES `voucher_series` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO bills VALUES("1","7","1","1","1","V00001","1","2025-04-10","2025-05-01","2025-04-01","32.00","0.00","32.00","32.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("2","1","1","1","1","V00002","11","2025-05-01","2025-06-01","2025-05-01","50.00","0.00","50.00","0.00","50.00","2","2","","","","","","4","");
INSERT INTO bills VALUES("3","1","1","1","1","V00003","12","2025-06-25","2025-07-01","2025-06-01","50.00","0.00","50.00","0.00","50.00","2","2","","","","","","4","");
INSERT INTO bills VALUES("4","7","2","1","1","V00004","13","2025-04-13","2025-04-13","0000-00-00","1.00","0.00","1.00","0.00","1.00","1","2","","","","","","4","");
INSERT INTO bills VALUES("5","7","2","1","1","V00005","14","2025-04-05","2025-05-05","2025-04-05","15.00","0.00","15.00","15.00","0.00","2","2","PAGO DE SERVICIO","","","","","1","");
INSERT INTO bills VALUES("6","7","6","1","1","V00006","15","2025-04-14","2025-04-14","0000-00-00","100.00","0.00","100.00","0.00","100.00","1","2","","","","","","4","");
INSERT INTO bills VALUES("7","7","6","1","1","V00007","16","2025-04-28","2025-04-28","2025-03-28","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","4","");
INSERT INTO bills VALUES("8","7","6","1","1","V00008","17","2025-04-14","2025-06-01","2025-05-01","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","4","");
INSERT INTO bills VALUES("9","7","5","1","1","V00009","18","2025-04-01","2025-04-01","0000-00-00","15.00","0.00","15.00","15.00","0.00","1","1","","","","","","1","");
INSERT INTO bills VALUES("10","7","5","1","1","V00010","19","2025-04-02","2025-04-02","2025-03-02","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("11","7","7","1","1","V00011","20","2025-04-02","2025-04-02","2025-03-02","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("12","7","28","1","1","V00012","21","2025-04-15","2025-04-17","2025-03-17","12.00","0.00","12.00","12.00","0.00","2","2","SERVICIO DE INTERNET","","","","","1","");
INSERT INTO bills VALUES("13","7","13","1","1","V00013","22","2025-04-15","2025-04-15","2025-03-15","20.00","0.00","20.00","20.00","0.00","2","2","PENDIENTE POR CANCELAR","","","","","1","");
INSERT INTO bills VALUES("14","7","9","1","1","V00014","23","2025-04-15","2025-04-16","2025-03-16","20.00","0.00","20.00","20.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("15","7","35","1","1","V00015","24","2025-04-21","2025-04-21","2025-03-21","20.00","0.00","20.00","20.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("17","7","33","1","1","V00017","26","2025-04-30","2025-04-30","2025-03-30","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("18","7","32","1","1","V00018","27","2025-04-28","2025-04-28","2025-03-28","20.00","0.00","20.00","20.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("19","7","31","1","1","V00019","28","2025-04-10","2025-04-10","2025-03-10","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("20","7","30","1","1","V00020","29","2025-04-26","2025-04-26","2025-03-26","20.00","0.00","20.00","20.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("21","7","29","1","1","V00021","30","2025-04-23","2025-04-23","2025-03-23","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("22","7","27","1","1","V00022","31","2025-04-28","2025-04-28","2025-03-28","10.00","0.00","10.00","10.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("23","7","26","1","1","V00023","32","2025-04-07","2025-04-07","2025-03-07","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("24","7","25","1","1","V00024","33","2025-03-25","2025-04-01","2025-03-01","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","3","");
INSERT INTO bills VALUES("25","7","24","1","1","V00025","34","2025-04-12","2025-04-12","2025-03-12","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("26","7","23","1","1","V00026","35","2025-04-15","2025-04-27","2025-03-27","20.00","0.00","20.00","20.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("27","7","22","1","1","V00027","36","2025-04-04","2025-04-04","2025-03-04","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("28","7","21","1","1","V00028","37","2025-04-15","2025-04-20","2025-03-20","20.00","0.00","20.00","20.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("29","7","20","1","1","V00029","38","2025-04-15","2025-04-28","2025-03-28","20.00","0.00","20.00","20.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("30","7","19","1","1","V00030","39","2025-04-05","2025-04-05","2025-03-05","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("31","7","18","1","1","V00031","40","2025-04-15","2025-04-18","2025-03-18","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("32","7","17","1","1","V00032","41","2025-04-12","2025-04-12","2025-03-12","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("33","7","16","1","1","V00033","42","2025-04-15","2025-04-30","2025-03-30","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("34","7","15","1","1","V00034","43","2025-04-05","2025-04-05","2025-03-05","20.00","0.00","20.00","20.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("35","7","14","1","1","V00035","44","2025-04-08","2025-04-08","2025-03-08","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("36","7","12","1","1","V00036","45","2025-04-15","2025-04-25","2025-03-25","10.00","0.00","10.00","10.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("37","7","11","1","1","V00037","46","2025-04-07","2025-04-07","2025-03-07","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("38","7","10","1","1","V00038","47","2025-04-15","2025-04-27","2025-03-27","20.00","0.00","20.00","20.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("39","7","8","1","1","V00039","48","2025-04-15","2025-04-26","2025-03-26","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("40","7","5","1","1","V00040","49","2025-04-15","2025-05-02","2025-04-02","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("41","7","4","1","1","V00041","50","2025-04-15","2025-04-20","2025-03-20","20.00","0.00","20.00","20.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("42","7","3","1","1","V00042","51","2025-04-15","2025-04-25","2025-03-25","15.00","0.00","15.00","15.00","0.00","2","2","PAGO CORRESPONDIENTE AL MES DE ABRIL","","","","","1","");
INSERT INTO bills VALUES("43","7","1","1","1","V00043","52","2025-04-19","2025-06-01","2025-05-01","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("44","7","26","1","1","V00044","53","2025-04-22","2025-05-07","2025-04-07","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("45","7","36","1","1","V00045","54","2025-04-24","2025-04-24","0000-00-00","40.00","0.00","40.00","40.00","0.00","1","1","","","","","","1","");
INSERT INTO bills VALUES("46","7","6","1","1","V00046","55","2025-04-27","2025-05-28","2025-04-28","15.00","0.00","15.00","15.00","0.00","2","2","PAGO REGISTRADO DEL MES DE ABRIL","","","","","1","");
INSERT INTO bills VALUES("47","7","7","1","1","V00047","56","2025-05-03","2025-05-02","2025-04-02","15.00","0.00","15.00","15.00","0.00","2","2","PAGO PROCESADO EXITOSAMENTE","","","","","1","");
INSERT INTO bills VALUES("48","7","7","1","1","V00048","57","2025-05-03","2025-06-02","2025-05-02","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("50","7","22","1","1","V00050","59","2025-05-04","2025-06-04","2025-04-04","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","3","");
INSERT INTO bills VALUES("51","7","19","1","1","V00051","60","2025-05-04","2025-06-05","2025-04-05","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","3","");
INSERT INTO bills VALUES("52","1","22","1","1","V00052","61","2025-06-04","2025-07-04","2025-06-04","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("53","1","19","1","1","V00053","62","2025-06-05","2025-07-05","2025-06-05","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("54","1","19","1","1","V00054","63","2025-07-05","2025-08-05","2025-07-05","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("55","1","25","1","1","V00055","64","2025-04-01","2025-05-01","2025-04-01","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","3","");
INSERT INTO bills VALUES("56","1","25","1","1","V00056","65","2025-05-01","2025-06-01","2025-05-01","30.00","0.00","30.00","30.00","0.00","2","2","PAGO ADELANTADO MES DE MAYO","","","","","1","");
INSERT INTO bills VALUES("57","1","25","1","1","V00057","66","2025-06-01","2025-07-01","2025-06-01","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("58","7","38","1","1","V00058","67","2025-05-01","2025-06-01","2025-05-06","132.00","50.00","82.00","82.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("59","7","38","1","1","V00059","68","2025-05-21","2025-07-01","2025-06-01","170.00","0.00","170.00","170.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("60","7","40","1","1","V00060","69","2025-05-21","2025-05-21","0000-00-00","2500.00","0.00","2500.00","2500.00","0.00","1","2","","","","","","1","");
INSERT INTO bills VALUES("61","7","40","1","1","V00061","70","2025-05-21","2025-06-02","2025-05-02","160.00","0.00","160.00","160.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("62","7","40","1","1","V00062","71","2025-05-22","2025-07-02","2025-06-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("63","7","40","1","1","V00063","72","2025-05-22","2025-08-02","2025-07-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("64","7","40","1","1","V00064","73","2025-05-22","2025-09-02","2025-08-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("65","7","40","1","1","V00065","74","2025-05-22","2025-10-02","2025-09-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("66","7","40","1","1","V00066","75","2025-05-22","2025-11-02","2025-10-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("67","7","40","1","1","V00067","76","2025-05-22","2025-12-02","2025-11-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("68","7","40","1","1","V00068","77","2025-05-22","2026-01-02","2025-12-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("69","7","40","1","1","V00069","78","2025-05-22","2026-02-02","2026-01-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("70","7","40","1","1","V00070","79","2025-05-22","2026-03-02","2026-02-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("71","1","40","1","1","V00071","80","2026-03-02","2026-04-02","2026-03-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("72","1","40","1","1","V00072","81","2026-04-02","2026-05-02","2026-04-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("73","1","40","1","1","V00073","82","2026-05-02","2026-06-02","2026-05-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("74","1","40","1","1","V00074","83","2026-06-02","2026-07-02","2026-06-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("75","1","40","1","1","V00075","84","2026-07-02","2026-08-02","2026-07-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("76","1","40","1","1","V00076","85","2026-08-02","2026-09-02","2026-08-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("77","1","40","1","1","V00077","86","2026-09-02","2026-10-02","2026-09-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("78","1","40","1","1","V00078","87","2026-10-02","2026-11-02","2026-10-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("79","1","40","1","1","V00079","88","2026-11-02","2026-12-02","2026-11-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("80","1","40","1","1","V00080","89","2026-12-02","2027-01-02","2026-12-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("81","1","40","1","1","V00081","90","2027-01-02","2027-02-02","2027-01-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("82","1","40","1","1","V00082","91","2027-02-02","2027-03-02","2027-02-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("83","1","40","1","1","V00083","92","2027-03-02","2027-04-02","2027-03-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("84","1","40","1","1","V00084","93","2027-04-02","2027-05-02","2027-04-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("85","1","40","1","1","V00085","94","2027-05-02","2027-06-02","2027-05-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("86","7","40","1","1","V00086","95","2025-05-23","2027-07-02","2027-06-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("87","7","40","1","1","V00087","96","2025-05-23","2027-08-02","2027-07-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("88","7","40","1","1","V00088","97","2025-05-23","2027-09-02","2027-08-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("89","7","35","1","1","V00089","98","2025-06-02","2025-05-21","2025-04-21","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","3","");
INSERT INTO bills VALUES("90","1","35","1","1","V00090","99","2025-05-21","2025-06-21","2025-05-21","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","3","");
INSERT INTO bills VALUES("91","1","35","1","1","V00091","100","2025-06-21","2025-07-21","2025-06-21","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("92","1","35","1","1","V00092","101","2025-07-21","2025-08-21","2025-07-21","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("93","1","35","1","1","V00093","102","2025-08-21","2025-09-21","2025-08-21","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("94","1","35","1","1","V00094","103","2025-09-21","2025-10-21","2025-09-21","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("95","1","35","1","1","V00095","104","2025-10-21","2025-11-21","2025-10-21","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("96","1","35","1","1","V00096","105","2025-11-21","2025-12-21","2025-11-21","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("97","1","35","1","1","V00097","106","2025-12-21","2026-01-21","2025-12-21","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","4","");
INSERT INTO bills VALUES("98","1","1","1","1","V00098","107","2025-06-02","2025-07-01","2025-06-01","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("99","1","2","1","1","V00099","108","2025-06-02","2025-07-05","2025-06-05","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("100","1","3","1","1","V00100","109","2025-06-02","2025-07-25","2025-06-25","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("101","1","4","1","1","V00101","110","2025-06-02","2025-07-20","2025-06-20","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("102","1","5","1","1","V00102","111","2025-06-02","2025-07-02","2025-06-02","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("103","1","6","1","1","V00103","112","2025-06-02","2025-07-28","2025-06-28","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("104","1","7","1","1","V00104","113","2025-06-02","2025-07-02","2025-06-02","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("105","1","8","1","1","V00105","114","2025-06-02","2025-07-26","2025-06-26","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("106","1","9","1","1","V00106","115","2025-06-02","2025-07-26","2025-06-26","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("107","1","10","1","1","V00107","116","2025-06-02","2025-07-27","2025-06-27","20.00","0.00","20.00","20.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("108","1","11","1","1","V00108","117","2025-06-02","2025-07-07","2025-06-07","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("109","1","12","1","1","V00109","118","2025-06-02","2025-07-25","2025-06-25","10.00","0.00","10.00","0.00","10.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("110","1","13","1","1","V00110","119","2025-06-02","2025-07-16","2025-06-16","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("111","1","14","1","1","V00111","120","2025-06-02","2025-07-08","2025-06-08","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("112","1","15","1","1","V00112","121","2025-06-02","2025-07-05","2025-06-05","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("113","1","16","1","1","V00113","122","2025-06-02","2025-07-28","2025-06-28","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("114","1","17","1","1","V00114","123","2025-06-02","2025-07-12","2025-06-12","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("115","1","18","1","1","V00115","124","2025-06-02","2025-07-18","2025-06-18","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("116","1","20","1","1","V00116","125","2025-06-02","2025-07-28","2025-06-28","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("117","1","21","1","1","V00117","126","2025-06-02","2025-07-20","2025-06-20","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("118","1","23","1","1","V00118","127","2025-06-02","2025-07-27","2025-06-27","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("119","1","24","1","1","V00119","128","2025-06-02","2025-07-12","2025-06-12","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("120","1","26","1","1","V00120","129","2025-06-02","2025-07-07","2025-06-07","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("121","1","27","1","1","V00121","130","2025-06-02","2025-07-28","2025-06-28","10.00","0.00","10.00","0.00","10.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("122","1","28","1","1","V00122","131","2025-06-02","2025-07-17","2025-06-17","12.00","0.00","12.00","0.00","12.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("123","1","29","1","1","V00123","132","2025-06-02","2025-07-23","2025-06-23","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("124","1","30","1","1","V00124","133","2025-06-02","2025-07-26","2025-06-26","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("125","1","31","1","1","V00125","134","2025-06-02","2025-07-10","2025-06-10","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("126","1","32","1","1","V00126","135","2025-06-02","2025-07-28","2025-06-28","20.00","0.00","20.00","0.00","20.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("127","1","33","1","1","V00127","136","2025-06-02","2025-07-28","2025-06-28","15.00","0.00","15.00","0.00","15.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("129","7","41","1","1","V00129","138","2025-06-03","2025-06-03","0000-00-00","0.00","0.00","0.00","0.00","0.00","1","1","D","","","","","1","");
INSERT INTO bills VALUES("130","7","40","1","1","V00130","139","2025-06-03","2027-10-02","2027-09-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("131","7","41","1","1","V00131","140","2025-06-03","2025-06-03","0000-00-00","3.20","0.00","3.20","3.20","0.00","1","2","","","","","","1","");
INSERT INTO bills VALUES("132","7","41","1","1","V00132","141","2025-06-03","2025-07-01","2025-06-01","10.00","0.00","10.00","10.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("133","7","39","1","1","V00133","142","2025-06-03","2025-06-03","0000-00-00","1500.00","0.00","1500.00","0.00","1500.00","1","2","","","","","","3","");
INSERT INTO bills VALUES("134","7","39","1","1","V00134","143","2025-06-03","2025-07-16","2025-06-16","18.00","0.00","18.00","0.00","18.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("137","7","40","1","1","V00137","146","2025-06-03","2027-11-02","2027-10-02","675.00","0.00","675.00","675.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("138","7","43","1","1","V00138","147","2025-03-25","2025-04-01","2025-03-01","8.00","0.00","8.00","5.00","3.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("139","7","43","1","1","V00139","148","2025-06-05","2025-05-01","2025-04-01","10.00","0.00","10.00","0.00","10.00","2","2","","","","","","3","");
INSERT INTO bills VALUES("140","7","43","1","1","V00140","149","2025-06-05","2025-06-01","2025-05-01","10.00","0.00","10.00","0.00","10.00","2","2","","1","2025-06-26","2025-06-25","Listo","3","");
INSERT INTO bills VALUES("141","7","44","1","1","V00141","150","2025-06-05","2025-06-05","0000-00-00","0.00","0.00","0.00","0.00","0.00","1","1","NINGUNO","","","","","1","");



DROP TABLE IF EXISTS business;

CREATE TABLE `business` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `documentid` bigint NOT NULL,
  `ruc` char(11) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `business_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `tradename` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `slogan` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile_refrence` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `email` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `password` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `server_host` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `port` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `department` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `province` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `district` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ubigeo` char(6) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `footer_text` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `currencyid` bigint NOT NULL,
  `print_format` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `logotyope` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `logo_login` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `logo_email` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `favicon` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `country_code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `google_apikey` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `reniec_apikey` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `background` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `whatsapp_api` varchar(100) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `whatsapp_key` varchar(100) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `month_corte` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`),
  KEY `currencyid` (`currencyid`),
  CONSTRAINT `business_ibfk_1` FOREIGN KEY (`documentid`) REFERENCES `document_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `business_ibfk_2` FOREIGN KEY (`currencyid`) REFERENCES `currency` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO business VALUES("4","1","132369076","TELGITCA","TELGITCA","JNKNKNKJ","414850720","414850720","","","","465","VEN. EDO. BOLIVAR.","","BOLIVAR","BOLIVAR","8001","<p style=\"text-align: center;\"><strong>Servicio de&nbsp; Internet:</strong></p>\n<p style=\"text-align: center;\"><strong> PAGO PROCESADO EXITOSAMENTE</strong></p>\n<p style=\"text-align: center;\">????<strong><span style=\"color: #e60b42;\">IMPORTANTE</span></strong></p>\n<p style=\"text-align: center;\"><span style=\"color: #000000;\">En caso de que el servicio este suspendido por falta de pago, las <strong>REACTIVACIONES</strong> se hacen de <strong>LUNES A VIERNES</strong> en los Horarios comprendidos:&nbsp;</span></p>\n<p style=\"text-align: center;\"><strong><span style=\"color: #000000;\">de 10:00. am&nbsp; a&nbsp; 6:00. p.m</span></strong></p>\n<p style=\"text-align: center;\">&nbsp;</p>\n<p style=\"text-align: center;\"><span style=\"color: #e60b42;\"><strong>NOTA:</strong></span></p>\n<p style=\"text-align: center;\"><span style=\"color: #e60b42;\"><strong>NO LABORAMOS NI SABADO, NI DOMINGO, NI DIAS FERIADOS.</strong></span></p>\n<p style=\"text-align: center;\">PARA CONSULTAR EL ESTATUS DE TU SERVICIO ACCEDE AL SIQUIENTE LINK.. Y CON TU NUMERO&nbsp; TELEFONICO SIN EL CERO PUEDES ACCEDER.</p>\n<p style=\"text-align: center;\"><strong>https://vps.wisppro.net/consultas</strong></p>\n<p style=\"text-align: center;\">&nbsp;</p>","5","a4","","","","","51","AIzaSyCqBa0JUtU2HSOYdpiKinJvJ4ZtjCEyjBw","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyNTAiLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiJjb25zdWx0b3IifQ.cQ6ZbYWbRkIK1-wmbU9rye-p12Wo7eRhQqS-cJlWJpc","bg-11.jpeg","https://api.conectate-ya.net.pe","1234567","2");



DROP TABLE IF EXISTS business_wsp;

CREATE TABLE `business_wsp` (
  `id` varchar(100) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `titulo` varchar(100) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `contenido` text COLLATE utf8mb4_spanish2_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO business_wsp VALUES("PAGO_MASSIVE","Confirmación de Registro de Pago internet","Estimado(a) *{cliente}*,\n\nNos complace informarle que hemos registrado su pago de *{payment_total}*, correspondiente al recibo de *{payment_months}*.\n\nAgradecemos su puntualidad y le agradecemos por continuar confiando en nuestros servicios.\n\nPara su conveniencia, puede descargar su recibo en el siguiente enlace:\n{list_payments}\n\nQuedamos a su disposición para cualquier consulta adicional.\n\nAtentamente,\n*{business_name}*");
INSERT INTO business_wsp VALUES("SUPPORT_TECNICO","SOPORTE TECNICO","Estimado(a) *{cliente}*,\n\nLe informamos que se ha generado el ticket Nº *{ticket_num}* para atender su solicitud. Un técnico se estará comunicando con usted a la brevedad para brindarle asistencia y solucionar el inconveniente con su servicio.\n\nQuedamos a su disposición para cualquier consulta adicional.\n\nAtentamente,\n*{business_name}*");
INSERT INTO business_wsp VALUES("PAYMENT_PENDING","PAGO PENDIENTE DE INTERNET","Estimado (a) cliente *{cliente}*, \nle recordamos que tiene una deuda *PENDIENTE* por el monto \n*TOTAL* de {debt_amount}, correspondiente a los siguientes *MESES:*\n\n{debt_list}\n\nGracias por formar parte de nuestra familia {business_name}, esperamos su pronto pago.\n\nAtte. {business_name}");
INSERT INTO business_wsp VALUES("PAYMENT_CONFIRMED","CONFIRMACIÓN DE PAGO INTERNET","Estimado(a) {cliente},\n\nLe informamos que se ha registrado su pago de {payment_total} correspondiente al recibo número {payment_num} de {payment_months}, quedando un saldo pendiente de {payment_pending}.\n\nPara su conveniencia, puede revisar los detalles de su pago en el siguiente enlace:\n{payment_links}\n\nAgradecemos su pago y la confianza depositada en nuestros servicios.\n\nAtentamente,\n{business_name}");
INSERT INTO business_wsp VALUES("CLIENT_ACTIVED","Restablecimiento de su Servicio","Estimado(a) *{cliente}*,\n\nLe informamos que su servicio ha sido restaurado con éxito. Ahora puede disfrutar nuevamente de su conexión sin inconvenientes.\n\nSi requiere asistencia adicional, no dude en contactarnos.\n\nGracias por su confianza.\n\nAtentamente,\n*{business_name}*");
INSERT INTO business_wsp VALUES("CLIENT_SUSPENDED","Suspensión de Servicio por Falta de Pago","Estimado(a) *{cliente}*,\n\nLe informamos que su servicio ha sido *suspendido* debido a la falta de pago. Actualmente, mantiene un saldo pendiente de {debt_total_list}, correspondiente a {debt_total_month_count}.\n\nPara regularizar su situación y restablecer el servicio, le solicitamos realizar el pago a la brevedad posible. Si ya ha efectuado el pago, le agradeceríamos que nos envíe el comprobante para su verificación.\n\nSi necesita más información o asistencia, no dude en comunicarse con nosotros a través de nuestros canales de atención.\n\nAtentamente,\n*{business_name}*");
INSERT INTO business_wsp VALUES("CLIENT_CANCELLED","Confirmación de Cancelación de Servicio","Estimado(a) *{cliente}*,\n\nLe informamos que su servicio ha sido cancelado.\n\nLamentamos su partida y agradecemos la confianza que nos brindó durante el tiempo que estuvo con nosotros. Si en el futuro decide regresar, estaremos encantados de recibirlo nuevamente.\n\nQuedamos a su disposición para cualquier consulta.\n\nAtentamente,\n*{business_name}*");
INSERT INTO business_wsp VALUES("SUSPENDED_NOTIFY","10 Días suspedidos","Estimado(a) *{cliente}*,");
INSERT INTO business_wsp VALUES("PROMISE_CREATED","Promesa Agregada","Listo lokito, dale al yape");



DROP TABLE IF EXISTS caja_nap;

CREATE TABLE `caja_nap` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `longitud` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitud` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `puertos` int NOT NULL,
  `detalles` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ubicacion` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(100) COLLATE utf8mb4_spanish2_ci NOT NULL DEFAULT 'nap',
  `color_tubo` varchar(100) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `color_hilo` varchar(100) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `zonaId` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO caja_nap VALUES("1","MUFA A1","-76.985290096875","-12.0555362668201","","es una mufa","LIMA","mufa","#ff0000","#e1ff00","1");
INSERT INTO caja_nap VALUES("2","Hco001","-76.2301165","-9.9181943","","Prin1","Hco1","mufa","#0000ff","#0000ff","1");
INSERT INTO caja_nap VALUES("3","Nap1","-76.2301165","-9.9181943","8","Nap 001","Hco001","nap","#0000ff","#0000ff","1");
INSERT INTO caja_nap VALUES("4","Nap 001","-76.23026079923167","-9.918510558400333","8","Nap 002","Hco001","nap","#0000ff","#0000ff","1");
INSERT INTO caja_nap VALUES("5","Nap 003","-76.22980651002604","-9.918752064591997","8","Nap 003","Hco 001","nap","#0000ff","#0000ff","1");
INSERT INTO caja_nap VALUES("6","NXP01-01","-71.94038910294735","-13.539385054214623","4",".","Velazco Astete","nap","#000000","#0040ff","4");
INSERT INTO caja_nap VALUES("7","eduardo","-96.8818688","32.948224","1","eee","eee","nap","#9c4f4f","#862323","1");



DROP TABLE IF EXISTS caja_nap_clientes;

CREATE TABLE `caja_nap_clientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cliente_id` int NOT NULL,
  `nap_id` int NOT NULL,
  `puerto` varchar(100) COLLATE utf8mb4_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO caja_nap_clientes VALUES("1","","3","1");
INSERT INTO caja_nap_clientes VALUES("2","","3","2");
INSERT INTO caja_nap_clientes VALUES("3","","3","3");
INSERT INTO caja_nap_clientes VALUES("4","","3","4");
INSERT INTO caja_nap_clientes VALUES("5","","3","5");
INSERT INTO caja_nap_clientes VALUES("6","","3","6");
INSERT INTO caja_nap_clientes VALUES("7","","3","7");
INSERT INTO caja_nap_clientes VALUES("8","","3","8");
INSERT INTO caja_nap_clientes VALUES("9","","4","1");
INSERT INTO caja_nap_clientes VALUES("10","","4","2");
INSERT INTO caja_nap_clientes VALUES("11","","4","3");
INSERT INTO caja_nap_clientes VALUES("12","","4","4");
INSERT INTO caja_nap_clientes VALUES("13","","4","5");
INSERT INTO caja_nap_clientes VALUES("14","","4","6");
INSERT INTO caja_nap_clientes VALUES("15","","4","7");
INSERT INTO caja_nap_clientes VALUES("16","","4","8");
INSERT INTO caja_nap_clientes VALUES("17","","5","1");
INSERT INTO caja_nap_clientes VALUES("18","","5","2");
INSERT INTO caja_nap_clientes VALUES("19","","5","3");
INSERT INTO caja_nap_clientes VALUES("20","","5","4");
INSERT INTO caja_nap_clientes VALUES("21","","5","5");
INSERT INTO caja_nap_clientes VALUES("22","","5","6");
INSERT INTO caja_nap_clientes VALUES("23","","5","7");
INSERT INTO caja_nap_clientes VALUES("24","","5","8");
INSERT INTO caja_nap_clientes VALUES("25","","6","1");
INSERT INTO caja_nap_clientes VALUES("26","","6","2");
INSERT INTO caja_nap_clientes VALUES("27","","6","3");
INSERT INTO caja_nap_clientes VALUES("28","","6","4");
INSERT INTO caja_nap_clientes VALUES("29","","7","1");



DROP TABLE IF EXISTS clients;

CREATE TABLE `clients` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `names` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `surnames` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `documentid` bigint NOT NULL,
  `document` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile_optional` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `reference` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `note` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `latitud` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `longitud` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  `net_router` int NOT NULL,
  `net_name` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `net_password` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `net_localaddress` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `net_ip` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `nap_cliente_id` int DEFAULT NULL,
  `ap_cliente_id` int DEFAULT NULL,
  `zonaid` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`),
  CONSTRAINT `clients_ibfk_1` FOREIGN KEY (`documentid`) REFERENCES `document_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO clients VALUES("1","JIM","MIREYA","1","","4249269388","","telgitca@gmail.com","URB. EL PERU, SECTOR 5 CASA SN","","","25.5739237","-80.9871074","1","3","test00","5HiUvQpwDbYXCoO9KYF74mUzS0ZGV01CM3AwM2U1K29WREY5bWc9PQ==","192.168.1.1","192.168.1.7","","","7");
INSERT INTO clients VALUES("2","SHAIRITH.","CAMPIS","1","","4160612600","","","URB. EL PERU SECTOR 5 VEREDA 83 CASA S/N","","","8.09487096909729","-63.57264737486877","1","3","SHAIRITH.-CAMPIS","obhP+copq0j8M43Vs4T4nW5zV1RrYnNqRVhkdlBWSjk1M040dWc9PQ==","","","","","7");
INSERT INTO clients VALUES("3","ELIDIASNI","SANCHEZ","1","","4129256271","","","URB. EL PERU, SECTOR 4, CASA S/N","","LAS CASITAS DELSECTOR 4","8.093648116767033","-63.569568198919676","1","","","","","","","1","3");
INSERT INTO clients VALUES("4","ROSAURA","BELISARIO.","5","14779060","4124643775","","rosaurabelisario31@hotmail.com","URB. EL PERU, SECTOR 4, CASA 06","","","8.0908970173934","-63.572068017721556","1","","","","","","","1","3");
INSERT INTO clients VALUES("5","OMIRA","HERNANDEZ","1","","4249084169","","noeliagutierrezv@gmail.com","URB. EL PERU SECTOR 5 CASA SN","","","8.094784080951495","-63.57274198919525","1","","","","","","","3","7");
INSERT INTO clients VALUES("6","MARIA EMPERATRIZ","RODRIGUEZ.","1","","4128792076","","","URB. EL PERU, SECTOR 3 CASA S/N AV. PRINCIPAL","","","8.093173629500898","-63.57205443141698","1","","","","","","","","3");
INSERT INTO clients VALUES("7","LUIS","AGUIRREZ","1","","4269312843","","","URB. EL PERU, SECTOR 4, CASA S/N","","","8.09283777763356","-63.571872953474426","1","","","","","","","5","5");
INSERT INTO clients VALUES("8","ANAIS","BARRERA","1","","4148577902","","","URB. EL PERU, SECTOR 3CASAS/N","","","8.094283693483062","-63.571726773083114","1","","","","","","","1","3");
INSERT INTO clients VALUES("9","OBDALYS MARIA","RAMOS FLOREZ","1","","4249126077","","","URB. EL PERU, SECTOR 3 CASA SN","","","25.5739237","-80.9871074","1","","","","","","","1","4");
INSERT INTO clients VALUES("10","GABRIEL","GARCIA","1","","4143888083","","","URB. EL PERU, SECTOR 5, AV. PRINCIPAL","","","8.09431157610685","-63.57226992040863","1","","","","","","","1","3");
INSERT INTO clients VALUES("11","ARANELYS","CRUZ.","5","19729430","4141910423","","cruzara@gmail.com","URB. EL PERU, SECTOR 5, VEREDA 64","","","8.09646118781662","-63.572629336416625","1","","","","","","","1","3");
INSERT INTO clients VALUES("12","JHON JAIVER","FRANCIA","1","","4120872703","","","URB. EL PERU, SECTOR 05, VEREDA 85 CASA 12","","","8.094586419009529","-63.572687003910445","1","","","","","","","3","7");
INSERT INTO clients VALUES("13","GLEINIS","RAMOS","5","16649114","4148767750","","gleinisramos@gmail.com","URB. EL PERU, SECTOR 03,CASAS /N","","","25.5739237","-80.9871074","1","","","","","","","1","4");
INSERT INTO clients VALUES("14","DAYANA","VECINA","1","","4249049169","","","URB. EL PERU, SECTOR 5, VEREDA 83","","","8.094790891385488","-63.57265481740227","1","","","","","","","3","7");
INSERT INTO clients VALUES("15","FRANCHEZKA DEL VALLE","COLMENARES VASQUEZ","5","28725976","4129932566","","colmenaresfrancheska2@gmail.com","URB. EL PERU, SECTOR 3, VEREDA 7, CASA 10","","","8.094664755841174","-63.57167447000732","1","","","","","","","1","3");
INSERT INTO clients VALUES("16","LINA","ALI","5","14653145","412790141","","linadelvalleali@gmail.com","URB. EL PERU, SECTOR 3, VEREDA 52, CASA 8","","","8.094312903850826","-63.56924438863983","1","","","","","","","1","4");
INSERT INTO clients VALUES("17","ANDREA","GARCIA","5","20556037","4127515450","","andreaaran03.2015@gmail.com","URB. EL PERU, SECTOR 3","","","8.094247844392504","-63.570450041592025","1","","","","","","","1","4");
INSERT INTO clients VALUES("18","MARIA ALEJANDRA","MARTINEZ","5","26722066","4128686670","","mariseb36@gmail.com","URB. EL PERU, SECTOR3 VEREDA 50, CASA 12","","","8.094419123351972","-63.57022205382576","1","","","","","","","1","4");
INSERT INTO clients VALUES("19","PAOLA SUAREZ","MARTINEZ","5","21578383","4120862584","","","URB. EL PERU, SECTOR 3, CALLE 15, CASA 20","","","8.094838690107812","-63.570172432958984","1","","","","","","","1","4");
INSERT INTO clients VALUES("20","FRANDER","RAMOS","5","32109588","4120911978","","","URB. EL PERU, SECTOR 3","","","8.094902421728651","-63.570660594999694","1","","","","","","","1","4");
INSERT INTO clients VALUES("21","REKIER RENE","COVA","1","","4124641486","","rekielvelandrina98@gmail.com","URB. EL PERU, SECTOR 3, CASA 12.","","","8.09626601045111","-63.57157254606476","1","","","","","","","1","4");
INSERT INTO clients VALUES("22","JOSE","CARRILLO","1","","4263946464","","","URB. EL PERU, SECTOR 4.","","","8.093756578756068","-63.56843167930832","1","","","","","","","1","4");
INSERT INTO clients VALUES("23","EZPERANZA","EZPERANZA","1","","4169453231","","","URBANIZACION EL PERU","","","8.100439067797248","-63.572045955955886","1","","","","","","","1","4");
INSERT INTO clients VALUES("24","LUIS","LUIS","1","","4147612917","","","URB. EL PERU SECTOR 5 CASA S/N","","","8.095067846978802","-63.57270980268709","1","","","","","","","3","7");
INSERT INTO clients VALUES("25","AISARI","GONZALEZ","1","","4167056965","","","URB. EL PERU SECTOR 3 CASA S/N","","","8.096775861329132","-63.57078934103241","1","","","","","","","1","4");
INSERT INTO clients VALUES("26","ANA","SALAZAR","1","","4128407402","4265951648","","URB. EL PERU SECTOR 5","","","8.102401438704119","-63.57215458542099","1","","","","","","","1","9");
INSERT INTO clients VALUES("27","PEDRO","RODRIGUEZ","1","","4148987366","4126946480","","URB. EL PERU SECTOR 5","","","8.101668538104546","-63.57403481394043","1","","","","","","","1","9");
INSERT INTO clients VALUES("28","JOSE","APARICIO","1","","4164926834","","","URB. EL PERU SECTOR 5","","","8.095260911908197","-63.57264140635719","1","","","","","","","5","3");
INSERT INTO clients VALUES("29","EVELYN","HERNANDEZ","5","19728043","4121183208","","evelynhernandez285@gmail.com","URB. EL PERU SECTOR 5, VEREDA 79,CASA 10","","","8.095874327697665","-63.572744671404266","1","","","","","","","1","4");
INSERT INTO clients VALUES("30","OSWALDO","RAMOS","1","","4148767750","","","URB. EL PERU SECTOR 3","","","8.093945118611694","-63.571740184128146","1","","","","","","","1","4");
INSERT INTO clients VALUES("31","JAIME","JAIME","1","","4249087012","4249087013","","URB,EL PERU SECTOR 5 CASA S/N","","","8.097126985770776","-63.57214117437585","1","","","","","","","1","4");
INSERT INTO clients VALUES("32","PASTOR","WILMAN LEON","5","11729615","4124990012","4264673228","ivoaro73@gmail.com","AV. PRERIMATRAL,SECTOR LAS BRISAS","","","8.079289201223142","-63.586845044195556","1","","","","","","","2","9");
INSERT INTO clients VALUES("33","TEDDYS","TEDDYS","1","","4124421873","","","URBANIZACION EL PERU SECTOR 5","","","8.09550475808961","-63.57235843330612","1","","","","","","","4","3");
INSERT INTO clients VALUES("35","JESUS","ZAMORA","5","19709806","4162996135","","","3 NBRISAS CRUCE PERIMETRAL VIA MARIPA","","","25.5739237","-80.9871074","1","","","","","","","2","9");
INSERT INTO clients VALUES("36","DANIELS","MEDINA","2","44179647","900600369","","rpinto.2704@gmail.com","PSJ. CANCHIS LT. 05 MZ. T3 URB. NESTOR CACERES V. III","","","","","1","5","daniels@bermudez.com","iEYdRFKpJqwI36dfEZkzTm1hdmVBM0U5WFNiM05BSy82T3g4WlE9PQ==","192.168.130.1","192.168.130.22","","","9");
INSERT INTO clients VALUES("37","JUAN ALBERTO CAPELO","CAPELO","2","22222222","999989898","","","CARRETERA SN","CERCA AL ARBOL","","16.791369599667142","-92.68689529731445","1","","","","","","","","1");
INSERT INTO clients VALUES("38","KATTY MELISSA","MONDRAGON ESPINOZA","1","","86421550","","","DE LA POLICIA, CUADRA Y MEDIA HACIA EL SUR, MEDIA HACIA EL ESTE. VILLANUEVA.","","","15.130854733195159","-91.79999847184449","1","5","KATTY-MELISSA-MONDRAGON-ESPINOZA","xCx9Kw3YRPPlgB+4KOmxGTFGS1gzdXBFcEtsUkZmWWxIV2pyWFE9PQ==","","","","","9");
INSERT INTO clients VALUES("39","GUILLER","FGHG","2","435","5514758204","","mladj@jpoier.com","REFOR #45","","","-9.9170244","-76.227927","1","6","GUILLER-FGHG","rJqEZlSdVppmN/Y0j2Dc0G16NlB5TnhIY3F3QUIwRmxOYU55eXVIamZRY2pBcEZzT2txQmsxVlpLdkU9","192.168.104.1","192.168.104.11","9","","4");
INSERT INTO clients VALUES("40","FELICIANO","HERNANDEZ","1","","7122274967","","cirilofelix_93@hotmail.com","1RA AVENIDA SAN CRISTOBAL","","","16.79131461419072","-92.68914335288697","1","6","tessss","EyAbjufToI/s2Khir/lLdXM0YzRJNHo3UExYZEt2b3c4UmJmbVE9PQ==","46.45.44.1","46.45.44.6","11","","1");
INSERT INTO clients VALUES("41","LEONARDO","JOSE","5","0302554019","3208484847","4698182416","leonardoproyectofedora@gmail.com","LA TRONCAL","","","-9.9170244","-76.227927","1","6","LEONARDO-JOSE","BXOVEr9Bmcqf3ir57luVGS91WEpiR2ViUjRQbisxcDh6Q1lkM0E9PQ==","46.45.44.1","46.45.44.8","","","");
INSERT INTO clients VALUES("42","HANS","MEIDNA","2","534543543","928237596","","","FDSFDS","","","-9.9170244","-76.227927","1","6","HANS-MEIDNA","QSCTI6+sNou5VbcbdQqlVEJ3QXZMbndydEQ3NnVjNjkycE9UZVZOYWhkN3VnSEZTcUNreWsyWEhPY2M9","46.45.44.1","46.45.44.5","","","3");
INSERT INTO clients VALUES("43","TESTE","DD","2","4343","928237596","999220735","","FDF","","","-9.9170345","-76.2279152","1","6","TESTE-DD","+AM6OKdK+c0+HKH44Bxq+G5rZkVvZXdpVnhaM3RMaVVvYlovTHVWWWFJM2Vzc1hmRVZCTG8yNU1qczA9","46.45.44.1","46.45.44.10","","","4");
INSERT INTO clients VALUES("44","ROMULO","ENRIQUEZ","4","6923568","74092156","","royd12enriquez@gmail.com","CALLE LOS MANGALES","IGLESIA","PLAN 20 MB","","","1","","","","","","","","1");
INSERT INTO clients VALUES("45","ASDFSAF","ASFASF","5","928837373636","928237596","","twd2206@gmail.com","JR SOL NACIENTE","","","","","1","","","","","","","","4");
INSERT INTO clients VALUES("46","ASDFSAF","ASFASF","5","928837373636","928237596","","twd2206@gmail.com","JR SOL NACIENTE","","","","","1","","","","","","","","4");
INSERT INTO clients VALUES("47","ASDFSAF","ASFASF","5","928837373636","928237596","","twd2206@gmail.com","JR SOL NACIENTE","","","","","1","","","","","","","","4");
INSERT INTO clients VALUES("48","ASDFSAF","ASFASF","5","928837373636","928237596","","twd2206@gmail.com","JR SOL NACIENTE","","","","","1","","","","","","","","4");
INSERT INTO clients VALUES("49","ASDFSAF","ASFASF","5","928837373636","928237596","","twd2206@gmail.com","JR SOL NACIENTE","","","","","1","","","","","","","","4");
INSERT INTO clients VALUES("50","ASDFSAF","ASFASF","5","928837373636","928237596","","twd2206@gmail.com","JR SOL NACIENTE","","","","","1","","","","","","","","4");



DROP TABLE IF EXISTS contracts;

CREATE TABLE `contracts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userid` bigint NOT NULL,
  `clientid` bigint NOT NULL,
  `internal_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `payday` bigint NOT NULL,
  `create_invoice` bigint NOT NULL,
  `days_grace` bigint NOT NULL,
  `discount` bigint NOT NULL,
  `discount_price` decimal(12,2) NOT NULL,
  `months_discount` bigint NOT NULL,
  `remaining_discount` bigint NOT NULL,
  `contract_date` datetime NOT NULL,
  `suspension_date` date DEFAULT NULL,
  `finish_date` date NOT NULL,
  `state` bigint NOT NULL,
  `modalidad` varchar(100) COLLATE utf8mb4_spanish2_ci NOT NULL DEFAULT 'POSTPAGO',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `clientid` (`clientid`),
  CONSTRAINT `contracts_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contracts_ibfk_3` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO contracts VALUES("1","7","1","CT00001","1","","5","","0.00","","","2025-04-10 12:46:17","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("2","7","2","CT00002","5","","","","0.00","","","2025-04-13 17:59:08","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("3","7","3","CT00003","25","","","","0.00","","","2025-04-14 10:33:03","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("4","7","4","CT00004","20","","","","0.00","","","2025-04-14 11:00:13","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("5","7","5","CT00005","2","","","","0.00","","","2025-04-14 11:16:01","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("6","7","6","CT00006","28","","","","0.00","","","2025-04-14 13:14:14","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("7","7","7","CT00007","2","","","","0.00","","","2025-04-14 20:27:09","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("8","7","8","CT00008","26","","","","0.00","","","2025-04-14 21:10:59","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("9","7","9","CT00009","26","","","","0.00","","","2025-04-14 21:23:47","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("10","7","10","CT00010","27","","","","0.00","","","2025-04-14 21:28:02","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("11","7","11","CT00011","7","","","","0.00","","","2025-04-14 21:32:09","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("12","7","12","CT00012","25","","","","0.00","","","2025-04-14 21:52:52","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("13","7","13","CT00013","16","","","","0.00","","","2025-04-14 21:59:54","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("14","7","14","CT00014","8","","","","0.00","","","2025-04-14 22:02:37","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("15","7","15","CT00015","5","","","","0.00","","","2025-04-14 22:06:50","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("16","7","16","CT00016","28","","2","","0.00","","","2025-04-14 22:12:08","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("17","7","17","CT00017","12","","","","0.00","","","2025-04-14 22:15:14","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("18","7","18","CT00018","18","","","","0.00","","","2025-04-14 22:17:48","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("19","7","19","CT00019","5","","","","0.00","","","2025-04-14 22:21:51","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("20","7","20","CT00020","28","","2","","0.00","","","2025-04-14 22:24:42","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("21","7","21","CT00021","20","","","","0.00","","","2025-04-14 22:32:54","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("22","7","22","CT00022","4","","","","0.00","","","2025-04-14 22:34:58","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("23","7","23","CT00023","27","","","","0.00","","","2025-04-14 22:37:44","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("24","7","24","CT00024","12","","","","0.00","","","2025-04-14 22:40:32","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("25","7","25","CT00025","1","","","","0.00","","","2025-04-14 22:45:23","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("26","7","26","CT00026","7","","","","0.00","","","2025-04-14 22:47:51","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("27","7","27","CT00027","28","","","","0.00","","","2025-04-14 22:58:46","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("28","7","28","CT00028","17","","","","0.00","","","2025-04-14 23:01:30","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("29","7","29","CT00029","23","","","","0.00","","","2025-04-14 23:04:36","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("30","7","30","CT00030","26","","","","0.00","","","2025-04-14 23:07:01","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("31","7","31","CT00031","10","","","","0.00","","","2025-04-14 23:10:20","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("32","7","32","CT00032","28","","","","0.00","","","2025-04-14 23:14:35","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("33","7","33","CT00033","28","","2","","0.00","","","2025-04-14 23:16:44","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("35","7","35","CT00035","21","","","","0.00","","","2025-04-14 23:32:45","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("36","7","36","CT00036","1","","5","","0.00","","","2025-04-24 12:56:04","0000-00-00","0000-00-00","1","POSTPAGO");
INSERT INTO contracts VALUES("37","7","37","CT00037","1","","5","","0.00","","","2025-05-04 01:25:24","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("38","7","38","CT00038","6","","5","","0.00","","","2025-05-06 11:52:47","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("39","7","39","CT00039","16","","4","","0.00","","","2025-05-19 20:08:26","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("40","7","40","CT00040","1","","5","","0.00","","","2025-05-21 14:23:38","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("41","7","41","CT00041","1","","5","","0.00","","","2025-06-03 10:44:20","0000-00-00","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("43","7","43","CT00043","1","","5","","0.00","","","2025-06-04 13:39:37","","0000-00-00","2","POSTPAGO");
INSERT INTO contracts VALUES("44","7","44","CT00044","22","","5","","0.00","","","2025-06-05 13:51:47","0000-00-00","0000-00-00","1","POSTPAGO");



DROP TABLE IF EXISTS cronjobs;

CREATE TABLE `cronjobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `frequency` int NOT NULL,
  `parm` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `parmdesc` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `parmx` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `lastrun` int NOT NULL,
  `lastresult` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `code` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO cronjobs VALUES("1","Notificación de deuda, mismo dia de pago (API-WhatsApp)","1440","","","","1748977923","Ejecuci&oacute;n autom&aacute;tica exitosa","IN001","1");
INSERT INTO cronjobs VALUES("2","Notificación de deudas a todos los clientes (API-WhatsApp)\n","43200","","","","1747166280","Ejecuci&oacute;n autom&aacute;tica exitosa","IN002","1");
INSERT INTO cronjobs VALUES("3","Corte de servicio de las facturas vencidas (respetando dia de gracia y promesas)","1440","","","","1743718115","Prueba exitosa","IN003","1");
INSERT INTO cronjobs VALUES("4","Envio masivo de deudas por correo electronico\n","43200","","","","1743718062","Prueba exitosa","CI001","");



DROP TABLE IF EXISTS cronjobs_core;

CREATE TABLE `cronjobs_core` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lastrun` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO cronjobs_core VALUES("1","1742076842");



DROP TABLE IF EXISTS cronjobs_exceptions;

CREATE TABLE `cronjobs_exceptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cronjobid` int NOT NULL,
  `clientid` int NOT NULL,
  `param_name` varchar(64) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `param_value` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS cronjobs_history;

CREATE TABLE `cronjobs_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cronjobid` int NOT NULL,
  `result` varchar(128) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `date` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO cronjobs_history VALUES("1","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1745444619");
INSERT INTO cronjobs_history VALUES("2","2","Ejecuci&oacute;n autom&aacute;tica exitosa","1747166280");
INSERT INTO cronjobs_history VALUES("3","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1748977923");



DROP TABLE IF EXISTS currency;

CREATE TABLE `currency` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `currency_iso` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `language` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `currency_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `money` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `money_plural` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `symbol` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO currency VALUES("1","PES","ES","PESOS COLOMBIANOS","PESO","PESOS","$","2022-07-07 19:57:37","1");
INSERT INTO currency VALUES("2","USD","ES","DOLAR USD","USD","DOLAR","$","2025-04-10 16:45:36","1");
INSERT INTO currency VALUES("3","BOL","ES","BOLIVAR FUERTE","BOLIVAR","BOLIVARES","BS.","2025-04-13 17:34:42","1");
INSERT INTO currency VALUES("4","NIO","EN","CóRDOBA","CóRDOBA","CóRDOBAS","C$","2025-05-03 14:59:50","1");
INSERT INTO currency VALUES("5","MXN","ES","PESOS MEXICANOS","PESO","PESOS","$","2025-05-21 22:09:27","1");



DROP TABLE IF EXISTS departures;

CREATE TABLE `departures` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `billid` bigint NOT NULL,
  `productid` bigint NOT NULL,
  `departure_date` datetime NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `quantity_departures` bigint NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `total_cost` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `billid` (`billid`),
  KEY `productid` (`productid`),
  CONSTRAINT `departures_ibfk_1` FOREIGN KEY (`productid`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS detail_bills;

CREATE TABLE `detail_bills` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `billid` bigint NOT NULL,
  `type` bigint NOT NULL,
  `serproid` bigint NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `quantity` bigint NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `billid` (`billid`),
  CONSTRAINT `detail_bills_ibfk_1` FOREIGN KEY (`billid`) REFERENCES `bills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=244 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO detail_bills VALUES("2","2","2","1","SERVICIO DE INTERNET HOGAR 10MB, MES DE MAYO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("6","3","2","1","SERVICIO DE INTERNET HOGAR 10MB, MES DE JUNIO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("7","4","1","","SERVICIO DE INSTALACIÓN","1","1.00","1.00");
INSERT INTO detail_bills VALUES("10","6","1","","SERVICIO DE INSTALACIÓN","1","100.00","100.00");
INSERT INTO detail_bills VALUES("12","8","2","4","SERVICIO DE PLAN 22 MEGAS, MES DE MAYO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("13","9","1","","SERVICIO DE INTERNET","1","15.00","15.00");
INSERT INTO detail_bills VALUES("19","1","2","1","SERVICIO DE INTERNET HOGAR 10MB, MES DE ABRIL PRORRATEADO","1","32.00","32.00");
INSERT INTO detail_bills VALUES("34","17","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("35","18","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE ABRIL PRORRATEADO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("37","20","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE ABRIL PRORRATEADO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("39","12","2","7","SERVICIO DE INTERNET RESIDENCIAL 19MB, MES DE ABRIL PRORRATEADO","1","12.00","12.00");
INSERT INTO detail_bills VALUES("40","22","2","9","SERVICIO DE INTERNET RESIDENCIA 19MB, MES DE ABRIL PRORRATEADO","1","10.00","10.00");
INSERT INTO detail_bills VALUES("42","23","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("46","25","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("48","26","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE ABRIL PRORRATEADO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("50","27","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("54","29","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE ABRIL PRORRATEADO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("55","28","2","8","SERVICIO DE INTERNET HOGAR 25MB, MES DE ABRIL PRORRATEADO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("57","30","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("59","31","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("61","32","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("63","33","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("65","34","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE ABRIL PRORRATEADO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("67","35","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("69","13","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE ABRIL PRORRATEADO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("71","36","2","1","SERVICIO DE INTERNET HOGAR 10MB, MES DE ABRIL PRORRATEADO","1","10.00","10.00");
INSERT INTO detail_bills VALUES("73","37","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("75","38","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE ABRIL PRORRATEADO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("77","14","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE ABRIL PRORRATEADO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("79","39","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("81","11","2","5","SERVICIO DE PLAN EN MEGAS, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("82","7","2","4","SERVICIO DE PLAN 22 MEGAS, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("83","10","2","5","SERVICIO DE PLAN 19 MEGAS, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("85","40","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL","1","15.00","15.00");
INSERT INTO detail_bills VALUES("87","41","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE ABRIL PRORRATEADO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("90","5","2","5","SERVICIO DE PLAN 19 MEGAS, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("91","19","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("92","43","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE MAYO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("93","21","2","4","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("94","44","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL","1","15.00","15.00");
INSERT INTO detail_bills VALUES("95","45","1","","PRUEBA DE FACTURA","2","20.00","40.00");
INSERT INTO detail_bills VALUES("96","15","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE ABRIL PRORRATEADO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("97","42","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("98","46","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("99","47","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL","1","15.00","15.00");
INSERT INTO detail_bills VALUES("100","48","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE MAYO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("105","50","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL","1","15.00","15.00");
INSERT INTO detail_bills VALUES("106","51","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL","1","15.00","15.00");
INSERT INTO detail_bills VALUES("107","52","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE MAYO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("108","53","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE MAYO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("109","54","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE MAYO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("110","24","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE MARZO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("111","55","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL","1","15.00","15.00");
INSERT INTO detail_bills VALUES("113","57","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL","1","15.00","15.00");
INSERT INTO detail_bills VALUES("114","58","2","11","SERVICIO DE PERFIL NETFLIX, MES DE MAYO PRORRATEADO","1","132.00","132.00");
INSERT INTO detail_bills VALUES("115","59","2","11","SERVICIO DE PERFIL NETFLIX, MES DE JUNIO","1","170.00","170.00");
INSERT INTO detail_bills VALUES("118","56","2","5","SERVICIO DE INTERNET HOGAR 19MB, MES DE ABRIL","1","15.00","15.00");
INSERT INTO detail_bills VALUES("119","56","1","","SERVICIO DE INTERNET HOGAR 19MB, MES DE MAYO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("120","60","1","","SERVICIO DE INSTALACIÓN","1","2500.00","2500.00");
INSERT INTO detail_bills VALUES("121","61","2","14","SERVICIO DE PLAN GAMER, MES DE MAYO PRORRATEADO","1","160.00","160.00");
INSERT INTO detail_bills VALUES("122","62","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("123","62","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("124","63","2","14","SERVICIO DE PLAN GAMER, MES DE JULIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("125","63","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JULIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("126","64","2","14","SERVICIO DE PLAN GAMER, MES DE AGOSTO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("127","64","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE AGOSTO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("128","65","2","14","SERVICIO DE PLAN GAMER, MES DE SEPTIEMBRE","1","550.00","550.00");
INSERT INTO detail_bills VALUES("129","65","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE SEPTIEMBRE","1","125.00","125.00");
INSERT INTO detail_bills VALUES("130","66","2","14","SERVICIO DE PLAN GAMER, MES DE OCTUBRE","1","550.00","550.00");
INSERT INTO detail_bills VALUES("131","66","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE OCTUBRE","1","125.00","125.00");
INSERT INTO detail_bills VALUES("132","67","2","14","SERVICIO DE PLAN GAMER, MES DE NOVIEMBRE","1","550.00","550.00");
INSERT INTO detail_bills VALUES("133","67","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE NOVIEMBRE","1","125.00","125.00");
INSERT INTO detail_bills VALUES("134","68","2","14","SERVICIO DE PLAN GAMER, MES DE DICIEMBRE","1","550.00","550.00");
INSERT INTO detail_bills VALUES("135","68","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE DICIEMBRE","1","125.00","125.00");
INSERT INTO detail_bills VALUES("136","69","2","14","SERVICIO DE PLAN GAMER, MES DE ENERO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("137","69","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE ENERO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("138","70","2","14","SERVICIO DE PLAN GAMER, MES DE FEBRERO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("139","70","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE FEBRERO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("140","71","2","14","SERVICIO DE PLAN GAMER, MES DE MARZO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("141","71","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE MARZO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("142","72","2","14","SERVICIO DE PLAN GAMER, MES DE MARZO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("143","72","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE MARZO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("144","73","2","14","SERVICIO DE PLAN GAMER, MES DE MARZO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("145","73","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE MARZO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("146","74","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("147","74","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("148","75","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("149","75","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("150","76","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("151","76","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("152","77","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("153","77","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("154","78","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("155","78","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("156","79","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("157","79","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("158","80","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("159","80","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("160","81","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("161","81","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("162","82","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("163","82","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("164","83","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("165","83","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("166","84","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("167","84","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("168","85","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("169","85","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("170","86","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("171","86","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JUNIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("172","87","2","14","SERVICIO DE PLAN GAMER, MES DE JULIO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("173","87","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE JULIO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("174","88","2","14","SERVICIO DE PLAN GAMER, MES DE AGOSTO","1","550.00","550.00");
INSERT INTO detail_bills VALUES("175","88","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE AGOSTO","1","125.00","125.00");
INSERT INTO detail_bills VALUES("176","89","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE ABRIL","1","20.00","20.00");
INSERT INTO detail_bills VALUES("177","90","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE MAYO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("178","91","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE MAYO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("179","92","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE MAYO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("180","93","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE MAYO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("181","94","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE MAYO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("182","95","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE MAYO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("183","96","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE MAYO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("184","97","2","4","SERVICIO DE INTERNET HOGAR 22MB, MES DE MAYO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("185","98","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("186","99","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("187","100","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("188","101","2","4","SERVICIO DE INTERNET HOGAR 22MB,MES DE JUNIO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("189","102","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("190","103","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("191","104","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("192","105","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("193","106","2","4","SERVICIO DE INTERNET HOGAR 22MB,MES DE JUNIO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("194","107","2","4","SERVICIO DE INTERNET HOGAR 22MB,MES DE JUNIO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("195","108","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("196","109","2","1","SERVICIO DE INTERNET HOGAR 10MB,MES DE JUNIO","1","10.00","10.00");
INSERT INTO detail_bills VALUES("197","110","2","4","SERVICIO DE INTERNET HOGAR 22MB,MES DE JUNIO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("198","111","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("199","112","2","4","SERVICIO DE INTERNET HOGAR 22MB,MES DE JUNIO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("200","113","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("201","114","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("202","115","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("203","116","2","4","SERVICIO DE INTERNET HOGAR 22MB,MES DE JUNIO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("204","117","2","8","SERVICIO DE INTERNET HOGAR 25MB,MES DE JUNIO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("205","118","2","4","SERVICIO DE INTERNET HOGAR 22MB,MES DE JUNIO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("206","119","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("207","120","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("208","121","2","9","SERVICIO DE JUAN,MES DE JUNIO","1","10.00","10.00");
INSERT INTO detail_bills VALUES("209","122","2","7","SERVICIO DE INTERNET RESIDENCIAL 19MB,MES DE JUNIO","1","12.00","12.00");
INSERT INTO detail_bills VALUES("210","123","2","4","SERVICIO DE INTERNET HOGAR 22MB,MES DE JUNIO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("211","124","2","4","SERVICIO DE INTERNET HOGAR 22MB,MES DE JUNIO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("212","125","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("213","126","2","4","SERVICIO DE INTERNET HOGAR 22MB,MES DE JUNIO","1","20.00","20.00");
INSERT INTO detail_bills VALUES("214","127","2","5","SERVICIO DE INTERNET HOGAR 19MB,MES DE JUNIO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("219","129","1","","","1","0.00","0.00");
INSERT INTO detail_bills VALUES("220","130","2","14","SERVICIO DE PLAN GAMER, MES DE SEPTIEMBRE","1","550.00","550.00");
INSERT INTO detail_bills VALUES("221","130","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE SEPTIEMBRE","1","125.00","125.00");
INSERT INTO detail_bills VALUES("222","131","1","","SERVICIO DE INSTALACIÓN","1","3.20","3.20");
INSERT INTO detail_bills VALUES("223","132","2","3","SERVICIO DE SDFS, MES DE JUNIO PRORRATEADO","1","10.00","10.00");
INSERT INTO detail_bills VALUES("224","133","1","","SERVICIO DE INSTALACIÓN","1","1500.00","1500.00");
INSERT INTO detail_bills VALUES("225","134","2","14","SERVICIO DE PLAN GAMER, MES DE JUNIO PRORRATEADO","1","18.00","18.00");
INSERT INTO detail_bills VALUES("230","137","2","14","SERVICIO DE PLAN GAMER, MES DE OCTUBRE","1","550.00","550.00");
INSERT INTO detail_bills VALUES("231","137","2","15","SERVICIO DE CINECANAL RECURRENTE, MES DE OCTUBRE","1","125.00","125.00");
INSERT INTO detail_bills VALUES("233","138","2","1","SERVICIO DE INTERNET HOGAR 10MB, MES DE MARZO","1","8.00","8.00");
INSERT INTO detail_bills VALUES("234","139","2","1","SERVICIO DE INTERNET HOGAR 10MB, MES DE ABRIL","1","10.00","10.00");
INSERT INTO detail_bills VALUES("235","140","2","1","SERVICIO DE INTERNET HOGAR 10MB, MES DE MAYO","1","10.00","10.00");
INSERT INTO detail_bills VALUES("236","141","1","","PLAN 20 MB","1","0.00","0.00");



DROP TABLE IF EXISTS detail_contracts;

CREATE TABLE `detail_contracts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contractid` bigint NOT NULL,
  `serviceid` bigint NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `contractid` (`contractid`),
  KEY `serviceid` (`serviceid`),
  CONSTRAINT `detail_contracts_ibfk_1` FOREIGN KEY (`contractid`) REFERENCES `contracts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_contracts_ibfk_2` FOREIGN KEY (`serviceid`) REFERENCES `services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO detail_contracts VALUES("1","1","5","15.00","2025-04-10 12:46:17","1");
INSERT INTO detail_contracts VALUES("2","2","5","15.00","2025-04-13 17:59:08","1");
INSERT INTO detail_contracts VALUES("3","3","5","15.00","2025-04-14 10:33:03","1");
INSERT INTO detail_contracts VALUES("4","4","4","20.00","2025-04-14 11:00:13","1");
INSERT INTO detail_contracts VALUES("5","5","5","15.00","2025-04-14 11:16:01","1");
INSERT INTO detail_contracts VALUES("6","6","5","15.00","2025-04-14 13:14:14","1");
INSERT INTO detail_contracts VALUES("7","7","5","15.00","2025-04-14 20:27:09","1");
INSERT INTO detail_contracts VALUES("8","8","5","15.00","2025-04-14 21:10:59","1");
INSERT INTO detail_contracts VALUES("9","9","4","20.00","2025-04-14 21:23:47","1");
INSERT INTO detail_contracts VALUES("10","10","4","20.00","2025-04-14 21:28:02","1");
INSERT INTO detail_contracts VALUES("11","11","5","15.00","2025-04-14 21:32:09","1");
INSERT INTO detail_contracts VALUES("12","12","1","10.00","2025-04-14 21:52:52","1");
INSERT INTO detail_contracts VALUES("13","13","4","20.00","2025-04-14 21:59:54","1");
INSERT INTO detail_contracts VALUES("14","14","5","15.00","2025-04-14 22:02:37","1");
INSERT INTO detail_contracts VALUES("15","15","4","20.00","2025-04-14 22:06:50","1");
INSERT INTO detail_contracts VALUES("16","16","5","15.00","2025-04-14 22:12:08","1");
INSERT INTO detail_contracts VALUES("17","17","5","15.00","2025-04-14 22:15:14","1");
INSERT INTO detail_contracts VALUES("18","18","5","15.00","2025-04-14 22:17:48","1");
INSERT INTO detail_contracts VALUES("19","19","5","15.00","2025-04-14 22:21:51","1");
INSERT INTO detail_contracts VALUES("20","20","4","20.00","2025-04-14 22:24:42","1");
INSERT INTO detail_contracts VALUES("21","21","8","20.00","2025-04-14 22:32:54","1");
INSERT INTO detail_contracts VALUES("22","22","5","15.00","2025-04-14 22:34:58","1");
INSERT INTO detail_contracts VALUES("23","23","4","20.00","2025-04-14 22:37:44","1");
INSERT INTO detail_contracts VALUES("24","24","5","15.00","2025-04-14 22:40:32","1");
INSERT INTO detail_contracts VALUES("25","25","5","15.00","2025-04-14 22:45:23","1");
INSERT INTO detail_contracts VALUES("26","26","5","15.00","2025-04-14 22:47:51","1");
INSERT INTO detail_contracts VALUES("27","27","9","10.00","2025-04-14 22:58:46","1");
INSERT INTO detail_contracts VALUES("28","28","7","12.00","2025-04-14 23:01:30","1");
INSERT INTO detail_contracts VALUES("29","29","4","20.00","2025-04-14 23:04:36","1");
INSERT INTO detail_contracts VALUES("30","30","4","20.00","2025-04-14 23:07:01","1");
INSERT INTO detail_contracts VALUES("31","31","5","15.00","2025-04-14 23:10:20","1");
INSERT INTO detail_contracts VALUES("32","32","4","20.00","2025-04-14 23:14:35","1");
INSERT INTO detail_contracts VALUES("33","33","5","15.00","2025-04-14 23:16:44","1");
INSERT INTO detail_contracts VALUES("35","35","4","20.00","2025-04-14 23:32:45","1");
INSERT INTO detail_contracts VALUES("36","36","4","20.00","2025-04-24 12:56:04","1");
INSERT INTO detail_contracts VALUES("40","37","7","12.00","2025-05-04 01:25:24","1");
INSERT INTO detail_contracts VALUES("41","38","11","170.00","2025-05-06 11:52:47","1");
INSERT INTO detail_contracts VALUES("42","39","14","550.00","2025-05-19 20:08:26","1");
INSERT INTO detail_contracts VALUES("43","40","14","550.00","2025-05-21 14:23:38","1");
INSERT INTO detail_contracts VALUES("44","40","15","125.00","2025-05-22 18:16:56","1");
INSERT INTO detail_contracts VALUES("45","41","3","12.00","2025-06-03 10:44:20","1");
INSERT INTO detail_contracts VALUES("47","43","1","10.00","2025-06-04 13:39:37","1");
INSERT INTO detail_contracts VALUES("48","44","14","550.00","2025-06-05 13:51:47","1");



DROP TABLE IF EXISTS detail_facility;

CREATE TABLE `detail_facility` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `facilityid` bigint NOT NULL,
  `technicalid` bigint NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `comment` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint NOT NULL,
  `red_type` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facilityid` (`facilityid`),
  KEY `technicalid` (`technicalid`),
  CONSTRAINT `detail_facility_ibfk_1` FOREIGN KEY (`facilityid`) REFERENCES `facility` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_facility_ibfk_2` FOREIGN KEY (`technicalid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO detail_facility VALUES("1","1","7","2025-04-10 12:46:30","2025-04-10 12:46:46","","1","1");
INSERT INTO detail_facility VALUES("2","2","7","2025-04-13 22:56:58","2025-04-13 22:57:45","","1","");
INSERT INTO detail_facility VALUES("3","3","7","2025-04-14 10:35:56","2025-04-14 10:38:37","","1","1");
INSERT INTO detail_facility VALUES("4","4","7","2025-04-14 11:02:13","2025-04-14 11:03:01","","1","1");
INSERT INTO detail_facility VALUES("5","6","7","2025-04-14 13:15:41","2025-04-14 13:16:07","TEST","1","");
INSERT INTO detail_facility VALUES("6","5","7","2025-04-14 19:14:32","2025-04-14 19:26:08","PROCESO EXITOSO","1","");
INSERT INTO detail_facility VALUES("7","7","7","2025-04-14 20:29:13","2025-04-14 20:34:43","LOS QUIPOS SON PROPIEDAD DEL CLIENTE","1","1");
INSERT INTO detail_facility VALUES("8","8","7","2025-04-14 21:12:49","2025-04-14 21:16:05","PROCESO EXITOSO","1","1");
INSERT INTO detail_facility VALUES("9","28","7","2025-04-15 07:14:41","2025-04-15 07:17:47","PROCESO EXITOSO","1","1");
INSERT INTO detail_facility VALUES("10","13","7","2025-04-15 07:33:50","2025-04-15 07:34:01","","1","1");
INSERT INTO detail_facility VALUES("11","9","7","2025-04-15 12:24:32","2025-04-15 12:24:55","","1","1");
INSERT INTO detail_facility VALUES("12","35","7","2025-04-15 21:07:13","2025-04-15 21:07:22","","1","1");
INSERT INTO detail_facility VALUES("14","33","7","2025-04-15 21:09:23","2025-04-15 21:11:01","","1","1");
INSERT INTO detail_facility VALUES("15","32","7","2025-04-15 21:11:12","2025-04-15 21:13:09","","1","1");
INSERT INTO detail_facility VALUES("16","31","7","2025-04-15 21:13:23","2025-04-15 21:15:53","","1","1");
INSERT INTO detail_facility VALUES("17","30","7","2025-04-15 21:16:32","2025-04-15 21:17:49","","1","1");
INSERT INTO detail_facility VALUES("18","29","7","2025-04-15 21:18:02","2025-04-15 21:19:41","","1","1");
INSERT INTO detail_facility VALUES("19","27","7","2025-04-15 21:20:08","2025-04-15 21:23:53","","1","1");
INSERT INTO detail_facility VALUES("20","26","7","2025-04-15 21:24:12","2025-04-15 21:26:13","","1","1");
INSERT INTO detail_facility VALUES("21","25","7","2025-04-15 21:26:26","2025-04-15 21:28:29","","1","");
INSERT INTO detail_facility VALUES("22","24","7","2025-04-15 21:29:01","2025-04-15 21:31:12","","1","");
INSERT INTO detail_facility VALUES("23","23","7","2025-04-15 21:31:23","2025-04-15 21:33:54","","1","1");
INSERT INTO detail_facility VALUES("24","22","7","2025-04-15 21:34:05","2025-04-15 21:36:58","","1","1");
INSERT INTO detail_facility VALUES("25","21","7","2025-04-15 21:37:08","2025-04-15 21:39:39","","1","1");
INSERT INTO detail_facility VALUES("26","20","7","2025-04-15 21:40:21","2025-04-15 21:42:16","","1","1");
INSERT INTO detail_facility VALUES("27","19","7","2025-04-15 21:42:50","2025-04-15 21:44:46","","1","1");
INSERT INTO detail_facility VALUES("28","18","7","2025-04-15 21:45:17","2025-04-15 21:49:54","","1","1");
INSERT INTO detail_facility VALUES("29","17","7","2025-04-15 21:51:23","2025-04-15 21:54:18","","1","1");
INSERT INTO detail_facility VALUES("30","16","7","2025-04-15 21:54:48","2025-04-15 21:56:00","","1","1");
INSERT INTO detail_facility VALUES("31","15","7","2025-04-15 21:56:35","2025-04-15 21:58:47","","1","1");
INSERT INTO detail_facility VALUES("32","14","7","2025-04-15 21:59:26","2025-04-15 22:01:18","","1","");
INSERT INTO detail_facility VALUES("33","12","7","2025-04-15 22:01:49","2025-04-15 22:03:05","","1","");
INSERT INTO detail_facility VALUES("34","11","7","2025-04-15 22:03:51","2025-04-15 22:05:15","","1","1");
INSERT INTO detail_facility VALUES("35","10","7","2025-04-15 22:05:38","2025-04-15 22:07:03","","1","1");
INSERT INTO detail_facility VALUES("36","38","7","2025-05-08 01:07:48","2025-05-08 01:08:06","","1","2");
INSERT INTO detail_facility VALUES("37","40","7","2025-05-21 14:25:12","2025-05-21 14:26:29","SE INSTALO SATISFACTORIAMENTE","1","2");
INSERT INTO detail_facility VALUES("38","41","7","2025-06-03 20:04:40","2025-06-03 20:05:35","","1","2");
INSERT INTO detail_facility VALUES("39","39","7","2025-06-03 20:06:08","2025-06-03 20:06:20","","1","1");
INSERT INTO detail_facility VALUES("40","42","7","2025-06-03 20:07:16","2025-06-03 20:07:21","","1","");
INSERT INTO detail_facility VALUES("41","37","7","2025-05-10 21:34:28","2025-06-03 23:56:37","SE HIZO LA INSTALACION CORRECTAMENTE, NO SE LE COBRARA UN MES DE PAGO.","1","");
INSERT INTO detail_facility VALUES("42","43","7","2025-06-04 13:39:47","2025-06-04 13:39:51","","1","");



DROP TABLE IF EXISTS document_type;

CREATE TABLE `document_type` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `document` varchar(100) COLLATE utf8mb3_spanish2_ci NOT NULL,
  `maxlength` int NOT NULL DEFAULT '8',
  `is_required` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

INSERT INTO document_type VALUES("1","SIN DOCUMENTO","8","");
INSERT INTO document_type VALUES("2","INE","8","1");
INSERT INTO document_type VALUES("3","SAT","11","1");
INSERT INTO document_type VALUES("4","CARNET DE EXTRANJERIA","20","");
INSERT INTO document_type VALUES("5","PASAPORTE","20","");



DROP TABLE IF EXISTS emails;

CREATE TABLE `emails` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `clientid` bigint NOT NULL,
  `billid` bigint NOT NULL,
  `affair` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `sender` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `files` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `type_file` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `template_email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `billid` (`billid`),
  CONSTRAINT `emails_ibfk_1` FOREIGN KEY (`billid`) REFERENCES `bills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `emails_ibfk_2` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO emails VALUES("1","1","3","FACTURA PENDIENTE DE PAGO","","true","ticket","notification","2025-04-13 23:48:19","2");
INSERT INTO emails VALUES("2","1","2","FACTURA PENDIENTE DE PAGO","","true","ticket","notification","2025-04-13 23:48:28","2");
INSERT INTO emails VALUES("3","1","3","FACTURA PENDIENTE DE PAGO","","true","ticket","notification","2025-04-13 23:50:09","2");
INSERT INTO emails VALUES("4","1","3","FACTURA PENDIENTE DE PAGO","","true","ticket","notification","2025-04-13 23:50:40","2");
INSERT INTO emails VALUES("5","1","3","FACTURA PENDIENTE DE PAGO","","true","ticket","notification","2025-04-13 23:50:52","2");
INSERT INTO emails VALUES("6","13","13","CONSTANCIA DE PAGO","","true","ticket","notification","2025-04-15 08:21:31","2");
INSERT INTO emails VALUES("7","17","32","CONSTANCIA DE PAGO","","true","ticket","notification","2025-04-16 20:53:49","2");
INSERT INTO emails VALUES("8","1","1","CONSTANCIA DE PAGO","","true","ticket","notification","2025-05-21 14:06:20","2");
INSERT INTO emails VALUES("9","41","129","CONSTANCIA DE PAGO","","true","ticket","notification","2025-06-03 14:28:23","2");



DROP TABLE IF EXISTS facility;

CREATE TABLE `facility` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `clientid` bigint NOT NULL,
  `userid` bigint NOT NULL,
  `technical` bigint NOT NULL,
  `attention_date` datetime NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `cost` decimal(12,2) NOT NULL,
  `detail` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`),
  KEY `technicalid` (`userid`),
  KEY `clientid` (`clientid`),
  CONSTRAINT `facility_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `facility_ibfk_3` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO facility VALUES("1","1","7","7","2025-04-10 13:45:00","2025-04-10 12:46:30","2025-04-10 12:46:46","0.00","","2025-04-10 12:46:17","1");
INSERT INTO facility VALUES("2","2","7","7","2025-04-05 18:55:00","2025-04-13 22:56:58","2025-04-13 22:57:45","1.00","","2025-04-13 17:59:08","1");
INSERT INTO facility VALUES("3","3","7","7","2025-03-25 11:27:00","2025-04-14 10:35:56","2025-04-14 10:38:37","0.00","TODOS LOS EQUIPOS SON PROPIEDAD DEL CLIENTE.","2025-04-14 10:33:03","1");
INSERT INTO facility VALUES("4","4","7","7","2025-03-20 11:49:00","2025-04-14 11:02:13","2025-04-14 11:03:01","0.00","los quipos son propiedad del cliente","2025-04-14 11:00:13","1");
INSERT INTO facility VALUES("5","5","7","7","2025-03-02 12:12:00","2025-04-14 19:14:32","2025-04-14 19:26:08","0.00","los quipos son propiedad del cliente","2025-04-14 11:16:01","1");
INSERT INTO facility VALUES("6","6","7","7","2025-04-14 12:12:00","2025-04-14 13:15:41","2025-04-14 13:16:07","100.00","","2025-04-14 13:14:14","1");
INSERT INTO facility VALUES("7","7","7","7","2025-04-02 21:25:00","2025-04-14 20:29:13","2025-04-14 20:34:43","0.00","los quipos son propiedad del cliente","2025-04-14 20:27:09","1");
INSERT INTO facility VALUES("8","8","7","7","2025-04-26 22:08:00","2025-04-14 21:12:49","2025-04-14 21:16:05","0.00","","2025-04-14 21:10:59","1");
INSERT INTO facility VALUES("9","9","7","7","2025-04-26 22:20:00","2025-04-15 12:24:32","2025-04-15 12:24:55","0.00","","2025-04-14 21:23:47","1");
INSERT INTO facility VALUES("10","10","7","7","2025-04-27 22:25:00","2025-04-15 22:05:38","2025-04-15 22:07:03","0.00","","2025-04-14 21:28:02","1");
INSERT INTO facility VALUES("11","11","7","7","2025-04-07 22:29:00","2025-04-15 22:03:51","2025-04-15 22:05:15","0.00","","2025-04-14 21:32:09","1");
INSERT INTO facility VALUES("12","12","7","7","2025-04-25 22:49:00","2025-04-15 22:01:49","2025-04-15 22:03:05","0.00","","2025-04-14 21:52:52","1");
INSERT INTO facility VALUES("13","13","7","7","2025-04-16 22:57:00","2025-04-15 07:33:50","2025-04-15 07:34:01","0.00","","2025-04-14 21:59:54","1");
INSERT INTO facility VALUES("14","14","7","7","2025-04-08 23:00:00","2025-04-15 21:59:26","2025-04-15 22:01:18","0.00","","2025-04-14 22:02:37","1");
INSERT INTO facility VALUES("15","15","7","7","2025-04-05 23:05:00","2025-04-15 21:56:35","2025-04-15 21:58:47","0.00","","2025-04-14 22:06:50","1");
INSERT INTO facility VALUES("16","16","7","7","2025-04-30 23:10:00","2025-04-15 21:54:48","2025-04-15 21:56:00","0.00","","2025-04-14 22:12:08","1");
INSERT INTO facility VALUES("17","17","7","7","2025-04-12 23:12:00","2025-04-15 21:51:23","2025-04-15 21:54:18","0.00","","2025-04-14 22:15:14","1");
INSERT INTO facility VALUES("18","18","7","7","2025-04-18 23:15:00","2025-04-15 21:45:17","2025-04-15 21:49:54","0.00","","2025-04-14 22:17:48","1");
INSERT INTO facility VALUES("19","19","7","7","2025-04-05 23:18:00","2025-04-15 21:42:50","2025-04-15 21:44:46","0.00","","2025-04-14 22:21:51","1");
INSERT INTO facility VALUES("20","20","7","7","2025-04-30 23:22:00","2025-04-15 21:40:21","2025-04-15 21:42:16","0.00","","2025-04-14 22:24:42","1");
INSERT INTO facility VALUES("21","21","7","7","2025-04-20 23:30:00","2025-04-15 21:37:08","2025-04-15 21:39:39","0.00","","2025-04-14 22:32:54","1");
INSERT INTO facility VALUES("22","22","7","7","2025-04-04 23:33:00","2025-04-15 21:34:05","2025-04-15 21:36:58","0.00","","2025-04-14 22:34:58","1");
INSERT INTO facility VALUES("23","23","7","7","2025-04-27 23:35:00","2025-04-15 21:31:23","2025-04-15 21:33:54","0.00","","2025-04-14 22:37:44","1");
INSERT INTO facility VALUES("24","24","7","7","2025-04-12 23:38:00","2025-04-15 21:29:01","2025-04-15 21:31:12","0.00","","2025-04-14 22:40:32","1");
INSERT INTO facility VALUES("25","25","7","7","2025-04-01 23:41:00","2025-04-15 21:26:26","2025-04-15 21:28:29","0.00","","2025-04-14 22:45:23","1");
INSERT INTO facility VALUES("26","26","7","7","2025-04-07 23:45:00","2025-04-15 21:24:12","2025-04-15 21:26:13","0.00","","2025-04-14 22:47:51","1");
INSERT INTO facility VALUES("27","27","7","7","2025-04-28 23:56:00","2025-04-15 21:20:08","2025-04-15 21:23:53","0.00","","2025-04-14 22:58:46","1");
INSERT INTO facility VALUES("28","28","7","7","2025-04-17 23:59:00","2025-04-15 07:14:41","2025-04-15 07:17:47","0.00","INSTALACION GRATIS","2025-04-14 23:01:30","1");
INSERT INTO facility VALUES("29","29","7","7","2025-04-23 00:01:00","2025-04-15 21:18:02","2025-04-15 21:19:41","0.00","INSTALACION GRATIS","2025-04-14 23:04:36","1");
INSERT INTO facility VALUES("30","30","7","7","2025-04-26 00:05:00","2025-04-15 21:16:32","2025-04-15 21:17:49","0.00","INSTALACION GRATIS","2025-04-14 23:07:01","1");
INSERT INTO facility VALUES("31","31","7","7","2025-04-10 00:08:00","2025-04-15 21:13:23","2025-04-15 21:15:53","0.00","INSTALACION GRATIS","2025-04-14 23:10:20","1");
INSERT INTO facility VALUES("32","32","7","7","2025-04-28 00:10:00","2025-04-15 21:11:12","2025-04-15 21:13:09","0.00","INSTALACION GRATIS","2025-04-14 23:14:35","1");
INSERT INTO facility VALUES("33","33","7","7","2025-04-30 00:14:00","2025-04-15 21:09:23","2025-04-15 21:11:01","0.00","INSTALACION GRATIS","2025-04-14 23:16:44","1");
INSERT INTO facility VALUES("35","35","7","7","2025-04-21 00:28:00","2025-04-15 21:07:13","2025-04-15 21:07:22","0.00","INSTALACION GRATIS","2025-04-14 23:32:45","1");
INSERT INTO facility VALUES("36","36","7","","2025-04-24 12:53:00","0000-00-00 00:00:00","0000-00-00 00:00:00","0.00","instalacion nueva+","2025-04-24 12:56:04","2");
INSERT INTO facility VALUES("37","37","7","7","2025-05-04 01:23:00","2025-05-10 21:34:28","2025-06-03 23:56:37","0.00","urgente","2025-05-04 01:25:24","1");
INSERT INTO facility VALUES("38","38","7","7","2025-05-06 10:45:00","2025-05-08 01:07:48","2025-05-08 01:08:06","0.00","","2025-05-06 11:52:47","1");
INSERT INTO facility VALUES("39","39","7","7","2025-05-29 22:03:00","2025-06-03 20:06:08","2025-06-03 20:06:20","1500.00","","2025-05-19 20:08:26","1");
INSERT INTO facility VALUES("40","40","7","7","2025-05-21 13:20:00","2025-05-21 14:25:12","2025-05-21 14:26:29","2500.00","","2025-05-21 14:23:38","1");
INSERT INTO facility VALUES("41","41","7","7","2025-06-03 10:34:00","2025-06-03 20:04:40","2025-06-03 20:05:35","3.20","df","2025-06-03 10:44:20","1");
INSERT INTO facility VALUES("42","42","7","7","2025-06-03 20:06:00","2025-06-03 20:07:16","2025-06-03 20:07:21","0.00","","2025-06-03 20:07:07","1");
INSERT INTO facility VALUES("43","43","7","7","2025-06-04 13:39:00","2025-06-04 13:39:47","2025-06-04 13:39:51","0.00","","2025-06-04 13:39:37","1");
INSERT INTO facility VALUES("44","44","7","1","2025-06-05 14:47:00","0000-00-00 00:00:00","0000-00-00 00:00:00","200.00","Instalado 20 de junio","2025-06-05 13:51:47","2");



DROP TABLE IF EXISTS forms_payment;

CREATE TABLE `forms_payment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO forms_payment VALUES("1","EFECTIVO","2025-04-10 12:49:05","1");
INSERT INTO forms_payment VALUES("2","TRANSFERENCIA","2025-04-10 16:45:59","1");
INSERT INTO forms_payment VALUES("3","PAGO MOVIL","2025-04-10 16:46:11","1");



DROP TABLE IF EXISTS gallery_images;

CREATE TABLE `gallery_images` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `clientid` bigint NOT NULL,
  `userid` bigint NOT NULL,
  `type` bigint NOT NULL,
  `typeid` bigint NOT NULL,
  `registration_date` datetime NOT NULL,
  `image` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO gallery_images VALUES("1","2","7","1","2","2025-04-13 22:57:40","shairith._campis_3a77f3e692e8ff195705c9abb167cea8.jpg");
INSERT INTO gallery_images VALUES("2","3","7","1","3","2025-04-14 10:38:27","elidiasni_sanchez_c4536a64da06dacef27d847299b93c61.jpg");
INSERT INTO gallery_images VALUES("3","6","7","1","6","2025-04-14 13:16:03","ines_barrera_5e32cfc09ee9f5cefcba60aaa4e95788.jpg");
INSERT INTO gallery_images VALUES("4","41","7","3","","2025-06-03 12:06:26","leonardo_jose_7695a798e191d29a3a7fac1d13c4f0d2.PNG");
INSERT INTO gallery_images VALUES("6","38","7","2","9","2025-06-03 12:28:25","katty_melissa_mondragon_espinoza_dd73779772d719a942a59f82fe646ddf.jpg");



DROP TABLE IF EXISTS incidents;

CREATE TABLE `incidents` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `incident` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO incidents VALUES("1","ALINEAR ANTENA","2025-04-10 12:52:47","1");
INSERT INTO incidents VALUES("2","POE DAÑADO","2025-04-10 12:52:55","1");
INSERT INTO incidents VALUES("3","OTROS","2025-04-10 12:53:00","1");
INSERT INTO incidents VALUES("4","INTERNET LENTO","2025-04-10 16:47:12","1");
INSERT INTO incidents VALUES("5","CAMBIIO DE CONECTOR","2025-04-13 17:36:33","1");
INSERT INTO incidents VALUES("6","LA ANTENE APAGA Y ENCIENDE CONSTANTEMENTE","2025-04-13 17:37:27","1");
INSERT INTO incidents VALUES("7","CONFIGURAR ROUTER","2025-04-13 17:37:49","1");
INSERT INTO incidents VALUES("8","INTERNET CAIDO","2025-04-13 17:39:01","1");
INSERT INTO incidents VALUES("9","INTERNET CORTADO","2025-04-13 17:39:19","1");



DROP TABLE IF EXISTS income;

CREATE TABLE `income` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `productid` bigint NOT NULL,
  `income_date` datetime NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `quantity_income` bigint NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `total_cost` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `productid` (`productid`),
  CONSTRAINT `income_ibfk_1` FOREIGN KEY (`productid`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `module` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO modules VALUES("1","Dashboard","1");
INSERT INTO modules VALUES("2","Clientes","1");
INSERT INTO modules VALUES("3","Usuarios","1");
INSERT INTO modules VALUES("4","Tickets","1");
INSERT INTO modules VALUES("5","Incidencias","1");
INSERT INTO modules VALUES("6","Facturas","1");
INSERT INTO modules VALUES("7","Productos","1");
INSERT INTO modules VALUES("8","Categorias","1");
INSERT INTO modules VALUES("9","Proveedores","1");
INSERT INTO modules VALUES("10","Pagos","1");
INSERT INTO modules VALUES("11","Servicios","1");
INSERT INTO modules VALUES("12","Empresa","1");
INSERT INTO modules VALUES("13","Instalaciones","1");
INSERT INTO modules VALUES("14","Divisas","1");
INSERT INTO modules VALUES("15","Formas de pago","1");
INSERT INTO modules VALUES("16","Comprobantes","1");
INSERT INTO modules VALUES("17","Unidades","1");
INSERT INTO modules VALUES("18","Correos","1");
INSERT INTO modules VALUES("19","Gestión de Red","1");
INSERT INTO modules VALUES("20","Campaña","1");



DROP TABLE IF EXISTS network_routers;

CREATE TABLE `network_routers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ip` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `port` int NOT NULL,
  `username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `password` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ip_range` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `zoneid` int NOT NULL,
  `identity` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `board_name` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `version` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `status` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO network_routers VALUES("6","mkdos","146.190.61.104","80","wispprored","mJloCpkIpKW3eZHovmthtVJhdVBNbnZRWktmR2lQUHluMEl6QVE9PQ==","46.45.44.1/24","1","","","","");
INSERT INTO network_routers VALUES("10","milkrotik 2","146.190.61.104","80","wispprored","mJloCpkIpKW3eZHovmthtVJhdVBNbnZRWktmR2lQUHluMEl6QVE9PQ==","46.45.44.1/24","1",""," "," "," ");



DROP TABLE IF EXISTS network_zones;

CREATE TABLE `network_zones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `mode` tinyint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO network_zones VALUES("1","PPPoE","2");
INSERT INTO network_zones VALUES("2","Simple Queues","1");



DROP TABLE IF EXISTS otros_ingresos;

CREATE TABLE `otros_ingresos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo` enum('INGRESO','EGRESO') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monto` decimal(12,2) DEFAULT NULL,
  `userId` int DEFAULT NULL,
  `state` enum('NORMAL','PENDIENTE','PAGADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NORMAL',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO otros_ingresos VALUES("1","EGRESO","2025-05-11","SE RECARGARON 100 USDT","105.00","7","PAGADO");
INSERT INTO otros_ingresos VALUES("2","INGRESO","2025-05-11","SE OBTUVIERON 3 CUENTAS NETFLIX EL DIA DE HOY ","950.00","7","NORMAL");
INSERT INTO otros_ingresos VALUES("3","EGRESO","2025-05-11","SE COMPRO MAQUINA DE FACTURACION NUEVA, LO DEJARAN EL PEDIDO EN DELIVERY EN LA AGENCIA CENTRAL","550.00","7","PENDIENTE");



DROP TABLE IF EXISTS p_campos;

CREATE TABLE `p_campos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `obligatorio` tinyint(1) DEFAULT NULL,
  `tablaId` int DEFAULT NULL,
  `tipo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO p_campos VALUES("4","VENCIDO","1","1","varchar","vencido");



DROP TABLE IF EXISTS p_tabla;

CREATE TABLE `p_tabla` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tabla` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO p_tabla VALUES("1","Ap Clientes","ap_clientes");
INSERT INTO p_tabla VALUES("2","Ap Emisor","ap_emisor");
INSERT INTO p_tabla VALUES("3","Ap Receptor","ap_receptor");



DROP TABLE IF EXISTS payments;

CREATE TABLE `payments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `billid` bigint NOT NULL,
  `userid` bigint NOT NULL,
  `clientid` bigint NOT NULL,
  `internal_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `paytypeid` bigint NOT NULL,
  `payment_date` datetime NOT NULL,
  `comment` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL,
  `amount_total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `remaining_credit` decimal(12,2) NOT NULL DEFAULT '0.00',
  `state` bigint NOT NULL DEFAULT '1',
  `ticket_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `reference_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `billid` (`billid`),
  KEY `clientid` (`clientid`),
  KEY `userid` (`userid`),
  KEY `paytypeid` (`paytypeid`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO payments VALUES("1","1","7","1","T00001","1","2025-04-10 13:49:00","","32.00","32.00","0.00","2","","");
INSERT INTO payments VALUES("2","5","7","2","T00002","3","2025-04-05 00:13:00","PAGO DE SERVICIO","15.00","15.00","0.00","2","","");
INSERT INTO payments VALUES("3","7","7","6","T00003","2","2025-04-14 12:16:00","","10.00","10.00","0.00","2","","");
INSERT INTO payments VALUES("4","9","7","5","T00004","1","2025-04-14 19:29:27","","0.00","15.00","15.00","","","");
INSERT INTO payments VALUES("5","10","7","5","T00005","3","2025-04-02 20:38:00","PAGO DE SERVICIO","15.00","15.00","0.00","2","","");
INSERT INTO payments VALUES("6","11","7","7","T00006","3","2025-04-02 21:38:00","PAGO REALISADO DESDE BANCO DE VENEZUELA","15.00","15.00","0.00","2","","");
INSERT INTO payments VALUES("7","12","7","28","T00007","3","2025-04-15 08:20:00","REALIZADA DESDE BANCO DE VENEZUELA","12.00","12.00","0.00","2","","");
INSERT INTO payments VALUES("8","13","7","13","T00008","3","2025-04-15 09:17:00","PAGO REALIZADO DESDE BANCO BANESCO BAJO LA REFERENCIA: 051051964256","20.00","20.00","0.00","2","","");
INSERT INTO payments VALUES("9","19","7","31","T00009","3","2025-03-29 23:48:00","PAGO REALIZADO DESDE CARONI","15.00","15.00","0.00","2","","");
INSERT INTO payments VALUES("10","12","7","28","T00010","3","2025-04-15 23:54:00","DESDE BANCO_DE_VENEZUELA_AL_BNC 943,00","12.00","12.00","0.00","1","","");
INSERT INTO payments VALUES("11","19","7","31","T00011","3","2025-04-10 23:58:00","DESDE_CARONI_AL_BNC 1.043,40","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("12","23","7","26","T00012","3","2025-04-07 00:00:00","DESDE_VENEZUELA_ALBNC 1.040,00","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("13","5","7","2","T00013","3","2025-04-16 00:03:00","DESDE_VENEZUELA_AL_MERCANTIL 1.041,00","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("14","13","7","13","T00014","3","2025-04-15 00:09:00","DESDE_BANESCO_AL_MERCANTIL 1.571,00","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("15","40","7","5","T00015","3","2025-04-16 00:11:00","","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("16","10","7","5","T00016","3","2025-05-01 00:11:00","","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("17","11","7","7","T00017","3","2025-04-16 00:13:00","DESDE_VENEZUELA_AL_BNC 1.100,00","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("18","25","7","24","T00018","3","2025-04-16 00:16:00","","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("19","30","7","19","T00019","3","2025-04-16 00:17:00","","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("20","32","7","17","T00020","3","2025-04-12 00:19:00","DESDE_VENEZUELA_AL_BNC","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("21","34","7","15","T00021","3","2025-04-05 00:21:00","DESDE_VENEZUELA_AL_MERCANTIL 1.392,00","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("22","35","7","14","T00022","3","2025-04-08 00:31:00","DESDE_VENEZUELA_AL_BNC 1.100,00","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("23","37","7","11","T00023","3","2025-04-07 00:34:00","DESDE_BANCARIBE_AL_BNC 1.082,70","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("24","14","7","9","T00024","3","2025-04-16 10:34:00","DESDE_CARONI_AL_MERCANTIL 1.595,60","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("25","31","7","18","T00025","3","2025-04-18 12:02:00","DESDE_BENCO_DE_VENEZUELA_AL:MERCANTIL 1.214.45 RF: 2603302141","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("26","18","7","32","T00026","3","2025-04-18 13:20:00","DESDE BANCO DE VENEZUELA AL MERCANTIL 1.620,00 RF: 2605101495","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("28","41","7","4","T00028","3","2025-04-20 11:12:00","DESDE BANCO DE VENEZUELA AL MERCANTIL 1.619,00 RF: 2613504874","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("29","21","7","29","T00029","3","2025-04-21 21:05:00","DESDE VENEZUELA AL BNC REF: 2622062926 1.200,00","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("30","44","7","26","T00030","3","2025-04-22 15:23:00","DESDE VENEZUELA AL BNC 1.226,40 REF: 2627029118","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("31","20","7","30","T00031","3","2025-04-22 20:05:00","DESDE BANESCO AL MERCANTIL POR 1.635,00 REF: 0511273388829","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("32","45","7","36","T00032","1","2025-04-24 13:00:51","","0.00","40.00","40.00","","","");
INSERT INTO payments VALUES("33","36","7","12","T00033","3","2025-04-25 21:36:00","DESDE VENEZUELA AL BNC 834,00 REF: 1045293709","10.00","10.00","0.00","1","","");
INSERT INTO payments VALUES("34","15","7","35","T00034","3","2025-04-24 21:44:00","DESDE VENEZUELA AL BNC 1.660,00 REF: 2640352290","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("35","17","7","33","T00035","3","2025-04-25 22:06:00","DESDE VENEZUELA AL BNC 1.266,00 REF: 2647481854","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("36","38","7","10","T00036","3","2025-05-27 11:24:00","DESDE VENEZUELA AL MERCANTIL 1.722,20 REF: 1048644958","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("37","42","7","3","T00037","3","2025-04-27 12:06:00","DESDE VENEZUELA AL BNC 1.266,00 REF: 1046100835","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("38","46","7","6","T00038","3","2025-04-27 12:14:00","DESDE MERCANTIL AL BNC 1.266,30 REF:811638419617","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("39","28","7","21","T00039","3","2025-04-27 19:38:00","DESDE MERCANTIL AL BNC 1.730,00 REF: 811739387088","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("40","29","7","20","T00040","1","2025-05-02 16:49:00","","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("41","26","7","23","T00041","1","2025-05-03 18:23:00","","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("42","33","7","16","T00042","1","2025-05-03 18:24:00","","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("43","39","7","8","T00043","1","2025-05-03 18:24:00","","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("44","47","7","7","T00044","3","2025-05-03 18:26:00","DESDE VENEZUELA AL BNC 1.314,00 REF: 2696883655","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("45","48","7","7","T00045","3","2025-05-03 18:30:00","DESDE VENEZUELA AL BNC 1.314,00 REF: 2696883655","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("46","43","7","1","T00046","1","2025-05-03 16:35:00","","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("47","27","7","22","T00047","1","2025-05-03 16:35:00","","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("48","24","7","25","T00048","1","2025-05-03 16:36:00","","15.00","15.00","0.00","2","","");
INSERT INTO payments VALUES("49","22","7","27","T00049","1","2025-05-03 16:36:00","","10.00","10.00","0.00","1","","");
INSERT INTO payments VALUES("50","1","7","1","T00050","1","2025-05-03 16:36:00","","32.00","32.00","0.00","1","","");
INSERT INTO payments VALUES("52","58","7","38","T00052","1","2025-05-18 18:49:00","","82.00","82.00","0.00","1","","");
INSERT INTO payments VALUES("53","59","7","38","T00053","1","2025-05-21 12:46:00","","170.00","170.00","0.00","1","","");
INSERT INTO payments VALUES("54","56","7","25","T00054","1","2025-05-21 13:01:00","PAGO POR ADELANTADO MES DE MAYO","30.00","30.00","0.00","1","","");
INSERT INTO payments VALUES("55","71","7","40","T00055","1","2025-05-22 17:23:00","","350.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("56","71","7","40","T00056","1","2025-05-22 17:24:00","","200.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("57","71","7","40","T00057","1","2025-05-22 17:24:00","","125.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("58","60","7","40","T00058","1","2025-05-23 22:14:00","PAGADO MES DE MAYO","2500.00","2500.00","0.00","1","","");
INSERT INTO payments VALUES("59","61","7","40","T00059","1","2025-05-23 22:15:00","","160.00","160.00","0.00","1","","");
INSERT INTO payments VALUES("60","62","7","40","T00060","1","2025-05-23 22:18:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("61","63","7","40","T00061","1","2025-05-23 22:18:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("62","88","7","40","T00062","1","2025-05-31 12:01:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("63","129","7","41","T00063","1","2025-06-03 12:31:39","","0.00","0.00","0.00","","","");
INSERT INTO payments VALUES("64","98","7","1","T00064","1","2025-06-03 12:38:00","","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("65","99","7","2","T00065","1","2025-06-03 20:18:00","","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("66","100","7","3","T00066","1","2025-06-03 20:19:00","","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("67","64","7","40","T00067","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("68","65","7","40","T00068","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("69","66","7","40","T00069","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("70","67","7","40","T00070","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("71","68","7","40","T00071","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("72","69","7","40","T00072","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("73","70","7","40","T00073","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("74","72","7","40","T00074","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("75","73","7","40","T00075","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("76","74","7","40","T00076","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("77","75","7","40","T00077","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("78","76","7","40","T00078","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("79","77","7","40","T00079","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("80","78","7","40","T00080","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("81","79","7","40","T00081","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("82","80","7","40","T00082","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("83","81","7","40","T00083","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("84","82","7","40","T00084","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("85","83","7","40","T00085","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("86","84","7","40","T00086","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("87","85","7","40","T00087","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("88","86","7","40","T00088","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("89","87","7","40","T00089","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("90","130","7","40","T00090","1","2025-06-03 22:33:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("91","135","7","42","T00091","1","2025-06-03 22:58:00","","10.00","10.00","0.00","1","","");
INSERT INTO payments VALUES("92","107","7","10","T00092","1","2025-06-04 18:16:00","","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("93","131","7","41","T00093","1","2025-06-04 19:47:00","","2.00","3.20","0.00","1","","");
INSERT INTO payments VALUES("94","131","7","41","T00094","1","2025-06-04 19:48:00","","1.20","3.20","0.00","1","","");
INSERT INTO payments VALUES("95","132","7","41","T00095","1","2025-06-04 19:48:00","","10.00","10.00","0.00","1","","");
INSERT INTO payments VALUES("96","104","7","7","T00096","1","2025-06-04 21:16:00","","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("97","137","7","40","T00097","1","2025-06-04 21:18:00","","675.00","675.00","0.00","1","","");
INSERT INTO payments VALUES("98","141","7","44","T00098","1","2025-06-05 13:54:25","","0.00","0.00","0.00","","","");
INSERT INTO payments VALUES("110","138","7","43","T00099","1","2025-06-25 14:18:00","","1.00","8.00","0.00","1","","");
INSERT INTO payments VALUES("111","138","7","43","T00100","1","2025-06-25 14:33:00","","1.00","8.00","0.00","1","","");
INSERT INTO payments VALUES("112","138","7","43","T00101","1","2025-06-25 14:33:00","","1.00","8.00","0.00","1","","");
INSERT INTO payments VALUES("113","138","7","43","T00102","1","2025-06-25 14:33:00","","1.00","8.00","0.00","1","","");
INSERT INTO payments VALUES("114","138","7","43","T00103","1","2025-06-25 14:33:00","","1.00","8.00","0.00","1","","");



DROP TABLE IF EXISTS permits;

CREATE TABLE `permits` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `profileid` bigint NOT NULL,
  `moduleid` bigint NOT NULL,
  `r` bigint NOT NULL,
  `a` bigint NOT NULL,
  `e` bigint NOT NULL,
  `v` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `profileid` (`profileid`),
  KEY `moduleid` (`moduleid`)
) ENGINE=InnoDB AUTO_INCREMENT=296 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO permits VALUES("19","2","1","","","","1");
INSERT INTO permits VALUES("20","2","2","1","","","1");
INSERT INTO permits VALUES("21","2","3","","","","");
INSERT INTO permits VALUES("22","2","4","1","1","","1");
INSERT INTO permits VALUES("23","2","5","","","","");
INSERT INTO permits VALUES("24","2","6","","","","");
INSERT INTO permits VALUES("25","2","7","","","","");
INSERT INTO permits VALUES("26","2","8","","","","");
INSERT INTO permits VALUES("27","2","9","","","","");
INSERT INTO permits VALUES("28","2","10","1","","","1");
INSERT INTO permits VALUES("29","2","11","","","","");
INSERT INTO permits VALUES("30","2","12","","","","");
INSERT INTO permits VALUES("31","2","13","1","1","","1");
INSERT INTO permits VALUES("32","2","14","","","","");
INSERT INTO permits VALUES("33","2","15","","","","");
INSERT INTO permits VALUES("34","2","16","","","","");
INSERT INTO permits VALUES("35","2","17","","","","");
INSERT INTO permits VALUES("36","2","18","","","","");
INSERT INTO permits VALUES("199","3","1","1","","1","1");
INSERT INTO permits VALUES("200","3","2","1","1","","1");
INSERT INTO permits VALUES("201","3","3","1","","","1");
INSERT INTO permits VALUES("202","3","4","1","1","","1");
INSERT INTO permits VALUES("203","3","5","1","","","1");
INSERT INTO permits VALUES("204","3","6","1","","","1");
INSERT INTO permits VALUES("205","3","7","1","","","1");
INSERT INTO permits VALUES("206","3","8","1","","","1");
INSERT INTO permits VALUES("207","3","9","1","","","1");
INSERT INTO permits VALUES("208","3","10","1","","","1");
INSERT INTO permits VALUES("209","3","11","1","","","1");
INSERT INTO permits VALUES("210","3","12","1","","","1");
INSERT INTO permits VALUES("211","3","13","1","1","1","1");
INSERT INTO permits VALUES("212","3","14","1","","","1");
INSERT INTO permits VALUES("213","3","15","1","","","1");
INSERT INTO permits VALUES("214","3","16","1","","","1");
INSERT INTO permits VALUES("215","3","17","1","","","1");
INSERT INTO permits VALUES("216","3","18","1","","","1");
INSERT INTO permits VALUES("276","1","1","1","1","1","1");
INSERT INTO permits VALUES("277","1","2","1","1","1","1");
INSERT INTO permits VALUES("278","1","3","1","1","1","1");
INSERT INTO permits VALUES("279","1","4","1","1","1","1");
INSERT INTO permits VALUES("280","1","5","1","1","1","1");
INSERT INTO permits VALUES("281","1","6","1","1","1","1");
INSERT INTO permits VALUES("282","1","7","1","1","1","1");
INSERT INTO permits VALUES("283","1","8","1","1","1","1");
INSERT INTO permits VALUES("284","1","9","1","1","1","1");
INSERT INTO permits VALUES("285","1","10","1","1","1","1");
INSERT INTO permits VALUES("286","1","11","1","1","1","1");
INSERT INTO permits VALUES("287","1","12","1","1","1","1");
INSERT INTO permits VALUES("288","1","13","1","1","1","1");
INSERT INTO permits VALUES("289","1","14","1","1","1","1");
INSERT INTO permits VALUES("290","1","15","1","1","1","1");
INSERT INTO permits VALUES("291","1","16","1","1","1","1");
INSERT INTO permits VALUES("292","1","17","1","1","1","1");
INSERT INTO permits VALUES("293","1","18","1","1","1","1");
INSERT INTO permits VALUES("294","1","19","1","1","1","1");
INSERT INTO permits VALUES("295","1","20","1","1","1","1");



DROP TABLE IF EXISTS product_category;

CREATE TABLE `product_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `category` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS products;

CREATE TABLE `products` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `internal_code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `barcode` varchar(13) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `product` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `model` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `brand` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `extra_info` bigint NOT NULL,
  `serial_number` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mac` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `sale_price` decimal(12,2) NOT NULL,
  `purchase_price` decimal(12,2) NOT NULL,
  `stock` bigint NOT NULL,
  `stock_alert` bigint NOT NULL,
  `categoryid` bigint NOT NULL,
  `unitid` bigint NOT NULL,
  `providerid` bigint NOT NULL,
  `image` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `categoryid` (`categoryid`),
  KEY `unitid` (`unitid`),
  KEY `providerid` (`providerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS profiles;

CREATE TABLE `profiles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `profile` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `description` varchar(300) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO profiles VALUES("1","ADMINISTRADOR","ACCESOS A TODOS LOS MODULOS","2022-07-07 15:51:53","1");
INSERT INTO profiles VALUES("2","TECNICO","CLIENTES, TICKET Y COBRANZA, CON RESTRICCIONES","2022-07-07 15:51:53","1");
INSERT INTO profiles VALUES("3","COBRANZA","COBRANZA DE FACTURAS PENDIENTES","2022-07-07 15:51:53","1");



DROP TABLE IF EXISTS providers;

CREATE TABLE `providers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `provider` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `documentid` bigint NOT NULL,
  `document` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO providers VALUES("1","TECNOLOGIA ALVARADO","1","123456789","1234567890","","C.C RIO CAURA","2025-04-13 15:31:03","1");
INSERT INTO providers VALUES("2","MEGA FIBRA","1","1234567890","1234567890","","C.C RIO CAURA","2025-04-13 15:31:52","1");



DROP TABLE IF EXISTS services;

CREATE TABLE `services` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `internal_code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `service` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `type` bigint NOT NULL,
  `rise` bigint NOT NULL,
  `rise_type` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `descent` bigint NOT NULL,
  `descent_type` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `details` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `routers` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  `profile` varchar(100) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO services VALUES("1","S00001","INTERNET HOGAR 10MB","1","5","MBPS","10","MBPS","10.00","CALIDAD DE SERVICIO Y GARANTIA","","2025-04-10 11:49:24","1","hans");
INSERT INTO services VALUES("2","S00002","X","2","","","","","1.00","","","2025-04-12 15:46:59","1","");
INSERT INTO services VALUES("3","S00003","SDFS","2","","","","","12.00","","","2025-04-12 15:47:13","1","");
INSERT INTO services VALUES("4","S00004","INTERNET HOGAR 22MB","1","5","MBPS","22","MBPS","20.00","CALIDAD SE SERVICIO Y GARANTIA","","2025-04-13 15:11:46","1","");
INSERT INTO services VALUES("5","S00005","INTERNET HOGAR 19MB","1","5","MBPS","19","MBPS","15.00","CALIDAD DE SERVICIO Y GARANTIA","","2025-04-13 15:12:26","1","");
INSERT INTO services VALUES("6","S00006","INTERNET HOGAR GRATIS","1","5","MBPS","22","MBPS","0.10","NO GARANTE","","2025-04-13 15:14:50","1","");
INSERT INTO services VALUES("7","S00007","INTERNET RESIDENCIAL 19MB","1","5","MBPS","19","MBPS","12.00","CALIDAD DE SERVICIO Y GARANTIA","","2025-04-14 21:49:41","1","");
INSERT INTO services VALUES("8","S00008","INTERNET HOGAR 25MB","1","5","MBPS","25","MBPS","20.00","CALIDAD DE SERVICIO Y GARANTIA","","2025-04-14 22:28:05","1","");
INSERT INTO services VALUES("9","S00009","JUAN","1","5","MBPS","19","MBPS","10.00","CALIDAD DE SERVICIO Y GARANTIA","","2025-04-14 22:52:37","1","oooo");
INSERT INTO services VALUES("10","S00010","MAX","2","","","","","100.00","","","2025-05-02 17:58:26","1","");
INSERT INTO services VALUES("11","S00011","PERFIL NETFLIX","2","","","","","170.00","","","2025-05-03 17:37:30","1","");
INSERT INTO services VALUES("12","S00012","DISNEY PLUS","2","","","","","150.00","","","2025-05-03 17:37:47","1","");
INSERT INTO services VALUES("13","S00013","CRUNCHYROLL","2","","","","","100.00","","","2025-05-08 01:12:48","1","");
INSERT INTO services VALUES("14","S00014","PLAN GAMER","1","70","MBPS","50","MBPS","550.00","INTERNET DE 70M 50M","","2025-05-18 19:38:56","1","");
INSERT INTO services VALUES("15","S00015","CINECANAL RECURRENTE","2","","","","","125.00","12333","","2025-05-22 18:15:45","1","");



DROP TABLE IF EXISTS ticket_solution;

CREATE TABLE `ticket_solution` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `ticketid` bigint NOT NULL,
  `technicalid` bigint NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `comment` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticketid` (`ticketid`),
  KEY `technicalid` (`technicalid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO ticket_solution VALUES("1","1","7","2025-04-10 12:55:21","2025-04-10 12:55:55","SE CAMBIO DE POE","1");
INSERT INTO ticket_solution VALUES("2","3","7","2025-04-16 20:42:34","2025-04-16 20:45:49","LA ANTENA SE HABIA RESETEADO POR FALTA DE MANTENIMIENTO.... EL PROBLEMA FUE SOLUCIONADO SATISFACTORIAMENTE YB TAMBIEN SE CAMBIO UN CONECTOR QUE ESTABA SULFATADO.. (EL CLIENTE QUEDO SATISFECHO)","1");
INSERT INTO ticket_solution VALUES("3","2","7","2025-04-19 15:13:10","2025-04-19 15:13:28","RESUELTO EXITOSO","1");
INSERT INTO ticket_solution VALUES("4","3","7","2025-04-16 20:49:37","2025-04-19 15:13:50","RESUELTO EXITOSAMENTE","1");
INSERT INTO ticket_solution VALUES("5","4","7","2025-04-19 15:13:58","2025-04-19 15:14:14","RESUELTO... EXITOSO","1");
INSERT INTO ticket_solution VALUES("6","5","7","2025-04-19 15:14:22","2025-04-19 15:14:33","RESUELTO EXITOSO","1");
INSERT INTO ticket_solution VALUES("7","6","7","2025-04-19 15:14:53","2025-04-19 15:15:06","RESUELTO EXITOSO","1");
INSERT INTO ticket_solution VALUES("8","8","7","2025-05-08 01:22:01","2025-05-08 01:22:07","INTE","1");
INSERT INTO ticket_solution VALUES("9","9","7","2025-05-08 01:21:49","2025-05-08 01:22:19","ATEB","1");
INSERT INTO ticket_solution VALUES("10","9","7","2025-05-10 22:05:59","2025-06-03 12:28:27","RRRRRRRRRRRRRR","1");



DROP TABLE IF EXISTS tickets;

CREATE TABLE `tickets` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userid` bigint NOT NULL,
  `clientid` bigint NOT NULL,
  `technical` bigint NOT NULL,
  `incidentsid` bigint NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `priority` bigint NOT NULL,
  `attention_date` datetime NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `clientid` (`clientid`),
  KEY `incidentsid` (`incidentsid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO tickets VALUES("1","1","1","7","2","AMIGOS DE LA EMPRESA x, NO TENGO INTERNET MI POE NO PRENDE LUZ BLANCA. ","4","2025-04-10 15:53:00","2025-04-10 12:55:21","2025-04-10 12:55:55","2025-04-10 12:54:19","1");
INSERT INTO tickets VALUES("2","1","1","7","3","nesecito que vengas urgente se me quemo el router","4","2025-04-14 12:17:00","2025-04-19 15:13:10","2025-04-19 15:13:28","2025-04-14 11:18:17","1");
INSERT INTO tickets VALUES("3","1","17","7","3","Mi antena no prende ","4","2025-04-16 20:57:00","2025-04-16 20:49:37","2025-04-19 15:13:50","2025-04-16 19:58:12","1");
INSERT INTO tickets VALUES("4","1","1","7","3","MALO","4","2025-04-18 13:32:00","2025-04-19 15:13:58","2025-04-19 15:14:14","2025-04-18 12:35:38","1");
INSERT INTO tickets VALUES("5","1","32","7","3","Interne malo ","4","2025-04-18 13:33:00","2025-04-19 15:14:22","2025-04-19 15:14:33","2025-04-18 12:36:03","1");
INSERT INTO tickets VALUES("6","1","21","7","3","Internet se cae a cada momento ","4","2025-04-18 18:26:00","2025-04-19 15:14:53","2025-04-19 15:15:06","2025-04-18 17:27:25","1");
INSERT INTO tickets VALUES("7","1","13","7","3","Internet lento ","4","2025-04-30 18:27:00","2025-05-02 15:54:08","0000-00-00 00:00:00","2025-04-30 17:28:12","3");
INSERT INTO tickets VALUES("8","7","3","7","1","IR UREGEN","4","2025-04-29 19:50:00","2025-05-10 22:06:25","2025-05-08 01:22:07","2025-05-02 19:50:33","3");
INSERT INTO tickets VALUES("9","7","38","7","3","","1","2025-05-06 11:00:00","2025-05-10 22:05:59","2025-06-03 12:28:27","2025-05-06 12:00:26","1");
INSERT INTO tickets VALUES("10","7","41","","2","DD","1","2025-06-03 12:30:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-06-03 12:31:05","5");
INSERT INTO tickets VALUES("11","7","41","","1","","1","2025-06-03 14:28:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-06-03 14:28:12","5");



DROP TABLE IF EXISTS tools;

CREATE TABLE `tools` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `facilityid` bigint NOT NULL,
  `productid` bigint NOT NULL,
  `quantity` bigint NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `product_condition` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `serie` varchar(150) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `mac` varchar(150) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facilityid` (`facilityid`),
  KEY `productid` (`productid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS unit;

CREATE TABLE `unit` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `united` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO unit VALUES("1","MEX","UNIDAD","2022-07-07 21:03:40","1");



DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `names` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `surnames` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `documentid` bigint NOT NULL,
  `document` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `email` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `profileid` bigint NOT NULL,
  `username` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `token` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `image` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`),
  KEY `profileid` (`profileid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO users VALUES("1","ADMIN","ADMIN","2","04801044274","85251599","rias12112@gmail.com","1","administrador","NDBqOXZsLzZ2aUpGVGtJNVF5eVNOdz09","","user_default.png","2022-07-07 19:39:22","1");
INSERT INTO users VALUES("7","TELGITCA","TELGITCA","2","12345678","4249269388","telecomunicacionesgittens@gmail.com","1","admin","cEo0bmRLQlVpSkQ3anVScXdmb3JTUT09","","profile_9f9252f919f0dc8bc2494a488979116e.JPG","2025-04-10 11:39:13","1");
INSERT INTO users VALUES("8","BEN","AR","2","60527","725","aS","3","sas","Q2RCaEJDbURJSUU0alhvdm1OUjVrdz09","","user_default.png","2025-06-04 21:09:06","1");



DROP TABLE IF EXISTS voucher_series;

CREATE TABLE `voucher_series` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `serie` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `fromc` bigint NOT NULL,
  `until` bigint NOT NULL,
  `voucherid` bigint NOT NULL,
  `available` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `voucherid` (`voucherid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO voucher_series VALUES("1","2022-07-07","R001","1","1000000","1","999845");



DROP TABLE IF EXISTS vouchers;

CREATE TABLE `vouchers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `voucher` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO vouchers VALUES("1","RECIBO","2022-07-07 17:37:14","1");
INSERT INTO vouchers VALUES("2","BAUCHE","2025-04-10 16:46:35","1");



DROP TABLE IF EXISTS zonas;

CREATE TABLE `zonas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre_zona` varchar(500) COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

INSERT INTO zonas VALUES("1","ZONA A","2025-04-10 11:45:15","1");
INSERT INTO zonas VALUES("2","ER JONATHAN","2025-04-13 17:42:59","1");
INSERT INTO zonas VALUES("3","PERUWIFI2.","2025-04-13 17:43:47","1");
INSERT INTO zonas VALUES("4","PERUWIFI4.","2025-04-13 17:44:02","1");
INSERT INTO zonas VALUES("5","PERUWIFI1.","2025-04-13 17:44:51","1");
INSERT INTO zonas VALUES("6","..","2025-04-13 17:45:32","1");
INSERT INTO zonas VALUES("7","SWICHERA PRINCIPAL","2025-04-13 17:46:16","1");
INSERT INTO zonas VALUES("8","SERVIDOR VPN","2025-04-13 17:46:56","1");
INSERT INTO zonas VALUES("9","PERUWIFI5.","2025-04-14 22:55:36","1");



SET FOREIGN_KEY_CHECKS=1;