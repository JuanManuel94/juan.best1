SET FOREIGN_KEY_CHECKS=0;

CREATE DATABASE IF NOT EXISTS u204188373_juanred;

USE u204188373_juanred;

DROP TABLE IF EXISTS ap_clientes;

CREATE TABLE `ap_clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ip` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `version` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO ap_clientes VALUES("1","Sectorial","192.16.90.2","Stable");



DROP TABLE IF EXISTS ap_emisor;

CREATE TABLE `ap_emisor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ip` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `version` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




DROP TABLE IF EXISTS ap_receptor;

CREATE TABLE `ap_receptor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci NOT NULL,
  `ip` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `version` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




DROP TABLE IF EXISTS archivos;

CREATE TABLE `archivos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `tipo` varchar(100) DEFAULT NULL,
  `size` int(11) NOT NULL,
  `ruta` text NOT NULL,
  `tabla` varchar(100) NOT NULL,
  `object_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO archivos VALUES("1","b0diTGxZdzNyQkNyM1FiejJUaHBOQT09.pdf","application/pdf","19247","Uploads/ap_clientes/1/b0diTGxZdzNyQkNyM1FiejJUaHBOQT09.pdf","ap_clientes","1");



DROP TABLE IF EXISTS backups;

CREATE TABLE `backups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `archive` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `size` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS bills;

CREATE TABLE `bills` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `clientid` bigint(20) NOT NULL,
  `voucherid` bigint(20) NOT NULL,
  `serieid` bigint(20) NOT NULL,
  `internal_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `correlative` bigint(20) NOT NULL,
  `date_issue` date NOT NULL,
  `expiration_date` date NOT NULL,
  `billed_month` date NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `discount` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL,
  `remaining_amount` decimal(12,2) NOT NULL,
  `type` bigint(20) NOT NULL,
  `sales_method` bigint(20) NOT NULL,
  `observation` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `promise_enabled` tinyint(4) NOT NULL,
  `promise_date` date DEFAULT NULL,
  `promise_set_date` date DEFAULT NULL,
  `promise_comment` varchar(512) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint(20) NOT NULL DEFAULT 2,
  `compromise_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `serviceid` (`clientid`),
  KEY `userid` (`userid`),
  KEY `voucherid` (`voucherid`),
  KEY `serieid` (`serieid`),
  CONSTRAINT `bills_ibfk_3` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bills_ibfk_5` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bills_ibfk_6` FOREIGN KEY (`voucherid`) REFERENCES `vouchers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bills_ibfk_7` FOREIGN KEY (`serieid`) REFERENCES `voucher_series` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO bills VALUES("1","1","1","1","1","V00001","1","2025-04-08","2025-05-01","2025-04-01","35.00","0.00","35.00","35.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("2","1","1","1","1","V00002","2","2025-04-08","2025-04-08","0000-00-00","15.00","0.00","15.00","15.00","0.00","1","1","","","","","","1","");
INSERT INTO bills VALUES("3","1","1","1","1","V00003","3","2025-04-08","2025-04-08","0000-00-00","20.00","0.00","20.00","20.00","0.00","1","2","","","","","","1","");
INSERT INTO bills VALUES("4","1","1","1","1","V00004","4","2025-04-08","2025-06-01","2025-05-01","50.00","0.00","50.00","50.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("5","1","1","1","1","V00005","5","2025-04-08","2025-07-01","2025-06-01","50.00","0.00","50.00","50.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("6","1","1","1","1","V00006","6","2025-04-08","2025-08-01","2025-07-01","50.00","0.00","50.00","50.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("7","1","1","1","1","V00007","7","2025-04-08","2025-09-01","2025-08-01","50.00","0.00","50.00","50.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("8","1","1","1","1","V00008","8","2025-04-08","2025-10-01","2025-09-01","50.00","0.00","50.00","50.00","0.00","2","2","","","2025-04-11","2025-04-09","nuevapromesa","1","");
INSERT INTO bills VALUES("9","1","1","1","1","V00009","9","2025-10-01","2025-11-01","2025-10-01","50.00","0.00","50.00","0.00","50.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("10","1","1","1","1","V00010","10","2025-11-01","2025-12-01","2025-11-01","50.00","0.00","50.00","0.00","50.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("11","1","2","1","1","V00011","11","2025-04-20","2025-04-20","0000-00-00","20.00","0.00","20.00","20.00","0.00","1","2","","","2025-04-21","2025-04-20","Okkkj","1","");
INSERT INTO bills VALUES("12","1","2","1","1","V00012","12","2025-04-20","2025-05-21","2025-04-21","15.00","5.00","10.00","10.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("13","1","2","1","1","V00013","13","2025-05-21","2025-06-21","2025-05-21","50.00","0.00","50.00","50.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("14","1","2","1","1","V00014","14","2025-04-20","2025-07-21","2025-06-21","50.00","0.00","50.00","50.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("15","1","2","1","1","V00015","15","2025-04-20","2025-08-21","2025-07-21","50.00","0.00","50.00","0.00","50.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("16","1","3","1","1","V00016","16","2025-04-20","2025-05-01","2025-04-01","15.00","0.00","15.00","15.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("17","1","3","1","1","V00017","17","2025-04-20","2025-06-01","2025-05-01","50.00","0.00","50.00","50.00","0.00","2","2","","","","","","1","");
INSERT INTO bills VALUES("18","1","3","1","1","V00018","18","2025-04-20","2025-07-01","2025-06-01","50.00","0.00","50.00","10.00","40.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("19","1","4","1","1","V00019","19","2025-05-04","2025-06-05","2025-05-05","42.00","0.00","42.00","0.00","42.00","2","2","","","","","","2","");
INSERT INTO bills VALUES("20","1","4","1","1","V00020","20","2025-05-04","2025-07-05","2025-06-05","50.00","0.00","50.00","0.00","50.00","2","2","","","","","","2","");



DROP TABLE IF EXISTS business;

CREATE TABLE `business` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `documentid` bigint(20) NOT NULL,
  `ruc` char(11) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `business_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `tradename` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `slogan` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile_refrence` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `email` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `password` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `server_host` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `port` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `department` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `province` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `district` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ubigeo` char(6) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `footer_text` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `currencyid` bigint(20) NOT NULL,
  `print_format` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `logotyope` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `logo_login` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `logo_email` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `favicon` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `country_code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `google_apikey` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `reniec_apikey` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `background` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `whatsapp_api` varchar(100) DEFAULT NULL,
  `whatsapp_key` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`),
  KEY `currencyid` (`currencyid`),
  CONSTRAINT `business_ibfk_1` FOREIGN KEY (`documentid`) REFERENCES `document_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `business_ibfk_2` FOREIGN KEY (`currencyid`) REFERENCES `currency` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO business VALUES("4","1","132369076","NETWORK SRL","SUPORTEC NETWORK SRL","","928237596","8297989774","","","","465","BONAO REP. DOM.","","BONAO","MONSENOR NOUEL","42000","","1","ticket","logo_0bbfd1974a6307327c659379b52671e6.png","login_0058d000c18f70d604f64b51ec17ec4a.png","","favicon_3f7114e86862f23a1f4b9b1ed428921c.png","51","AIzaSyCqBa0JUtU2HSOYdpiKinJvJ4ZtjCEyjBw","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyNTAiLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiJjb25zdWx0b3IifQ.cQ6ZbYWbRkIK1-wmbU9rye-p12Wo7eRhQqS-cJlWJpc","bg-8.jpeg","https://api.conectate-ya.net.pe","75116544");



DROP TABLE IF EXISTS business_wsp;

CREATE TABLE `business_wsp` (
  `id` varchar(100) NOT NULL,
  `titulo` varchar(100) DEFAULT NULL,
  `contenido` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO business_wsp VALUES("PAGO_MASSIVE","Confirmación de Registro de Pago","Estimado(a) *{cliente}*,\n\nNos complace informarle que hemos registrado su pago de *{payment_total}*, correspondiente al recibo de *{payment_months}*.\n\nAgradecemos su puntualidad y le agradecemos por continuar confiando en nuestros servicios.\n\nPara su conveniencia, puede descargar su recibo en el siguiente enlace:\n{list_payments}\n\nQuedamos a su disposición para cualquier consulta adicional.\n\nAtentamente,\n*{business_name}*");
INSERT INTO business_wsp VALUES("SUPPORT_TECNICO","SOPORTE TECNICO","Estimado(a) *{cliente}*,\n\nLe informamos que se ha generado el ticket Nº *{ticket_num}* para atender su solicitud. Un técnico se estará comunicando con usted a la brevedad para brindarle asistencia y solucionar el inconveniente con su servicio.\n\nQuedamos a su disposición para cualquier consulta adicional.\n\nAtentamente,\n*{business_name}*");
INSERT INTO business_wsp VALUES("PAYMENT_PENDING","PAGO PENDIENTE","Estimado cliente *{cliente}*, \nle recordamos que tiene una deuda *PENDIENTE* por el monto \n*TOTAL* de {debt_amount}, correspondiente a los siguientes *MESES:*\n\n{debt_list}\n\nGracias por formar parte de nuestra familia {business_name}, esperamos su pronto pago.\n\nAtte. {business_name}");
INSERT INTO business_wsp VALUES("PAYMENT_CONFIRMED","CONFIRMACIÓN DE PAGO","Estimado(a) {cliente},\n\nLe informamos que se ha registrado su pago de {payment_total} correspondiente al recibo número {payment_num} de {payment_months}, quedando un saldo pendiente de {payment_pending}.\n\nPara su conveniencia, puede revisar los detalles de su pago en el siguiente enlace:\n{payment_links}\n\nAgradecemos su pago y la confianza depositada en nuestros servicios.\n\nAtentamente,\n{business_name}");
INSERT INTO business_wsp VALUES("CLIENT_ACTIVED","Restablecimiento de su Servicio","Estimado(a) *{cliente}*,\n\nLe informamos que su servicio ha sido restaurado con éxito. Ahora puede disfrutar nuevamente de su conexión sin inconvenientes.\n\nSi requiere asistencia adicional, no dude en contactarnos.\n\nGracias por su confianza.\n\nAtentamente,\n*{business_name}*");
INSERT INTO business_wsp VALUES("CLIENT_SUSPENDED","Suspensión de Servicio por Falta de Pago","Estimado(a) *{cliente}*,\n\nLe informamos que su servicio ha sido *suspendido* debido a la falta de pago. Actualmente, mantiene un saldo pendiente de {debt_total_list}, correspondiente a {debt_total_month_count}.\n\nPara regularizar su situación y restablecer el servicio, le solicitamos realizar el pago a la brevedad posible. Si ya ha efectuado el pago, le agradeceríamos que nos envíe el comprobante para su verificación.\n\nSi necesita más información o asistencia, no dude en comunicarse con nosotros a través de nuestros canales de atención.\n\nAtentamente,\n*{business_name}*");
INSERT INTO business_wsp VALUES("CLIENT_CANCELLED","Confirmación de Cancelación de Servicio","Estimado(a) *{cliente}*,\n\nLe informamos que su servicio ha sido cancelado.\n\nLamentamos su partida y agradecemos la confianza que nos brindó durante el tiempo que estuvo con nosotros. Si en el futuro decide regresar, estaremos encantados de recibirlo nuevamente.\n\nQuedamos a su disposición para cualquier consulta.\n\nAtentamente,\n*{business_name}*");



DROP TABLE IF EXISTS caja_nap;

CREATE TABLE `caja_nap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `longitud` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitud` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `puertos` int(11) NOT NULL,
  `detalles` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ubicacion` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(100) NOT NULL DEFAULT 'nap',
  `color_tubo` varchar(100) DEFAULT NULL,
  `color_hilo` varchar(100) DEFAULT NULL,
  `zonaId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO caja_nap VALUES("1","MUFA","-76.79842705","-9.853997513927462","","nada","nose ok","mufa","#f00505","#05d5ff","1");
INSERT INTO caja_nap VALUES("2","otro","-78.545253221875","-9.076466599972003","","dsds","saas","mufa","#1486f0","#76ff05","2");
INSERT INTO caja_nap VALUES("3","caja","-78.545253221875","-9.076466599972003","8","detallrs ok","aaaa","nap","#f09999","#ff5900","3");
INSERT INTO caja_nap VALUES("4","caja cedro","-77.0087831","-11.853836","12","ssa","los cedros","nap","#e81111","#115bee","2");
INSERT INTO caja_nap VALUES("5","Prueba","-78.54748340532923","-9.072336119128117","20","Ok","JR prueba ","nap","#ff0000","#00ffff","2");



DROP TABLE IF EXISTS caja_nap_clientes;

CREATE TABLE `caja_nap_clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) NOT NULL,
  `nap_id` int(11) NOT NULL,
  `puerto` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO caja_nap_clientes VALUES("1","","3","1");
INSERT INTO caja_nap_clientes VALUES("2","","3","2");
INSERT INTO caja_nap_clientes VALUES("3","","3","3");
INSERT INTO caja_nap_clientes VALUES("4","","3","4");
INSERT INTO caja_nap_clientes VALUES("5","","3","5");
INSERT INTO caja_nap_clientes VALUES("6","","3","6");
INSERT INTO caja_nap_clientes VALUES("7","","3","7");
INSERT INTO caja_nap_clientes VALUES("8","","3","8");
INSERT INTO caja_nap_clientes VALUES("9","","4","1");
INSERT INTO caja_nap_clientes VALUES("10","","4","2");
INSERT INTO caja_nap_clientes VALUES("11","","4","3");
INSERT INTO caja_nap_clientes VALUES("12","","4","4");
INSERT INTO caja_nap_clientes VALUES("13","","4","5");
INSERT INTO caja_nap_clientes VALUES("14","","4","6");
INSERT INTO caja_nap_clientes VALUES("15","","4","7");
INSERT INTO caja_nap_clientes VALUES("16","","4","8");
INSERT INTO caja_nap_clientes VALUES("17","","4","9");
INSERT INTO caja_nap_clientes VALUES("18","","4","10");
INSERT INTO caja_nap_clientes VALUES("19","","4","11");
INSERT INTO caja_nap_clientes VALUES("20","","4","12");
INSERT INTO caja_nap_clientes VALUES("21","","5","1");
INSERT INTO caja_nap_clientes VALUES("22","","5","2");
INSERT INTO caja_nap_clientes VALUES("23","","5","3");
INSERT INTO caja_nap_clientes VALUES("24","","5","4");
INSERT INTO caja_nap_clientes VALUES("25","","5","5");
INSERT INTO caja_nap_clientes VALUES("26","","5","6");
INSERT INTO caja_nap_clientes VALUES("27","","5","7");
INSERT INTO caja_nap_clientes VALUES("28","","5","8");
INSERT INTO caja_nap_clientes VALUES("29","","5","9");
INSERT INTO caja_nap_clientes VALUES("30","","5","10");
INSERT INTO caja_nap_clientes VALUES("31","","5","11");
INSERT INTO caja_nap_clientes VALUES("32","","5","12");
INSERT INTO caja_nap_clientes VALUES("33","","5","13");
INSERT INTO caja_nap_clientes VALUES("34","","5","14");
INSERT INTO caja_nap_clientes VALUES("35","","5","15");
INSERT INTO caja_nap_clientes VALUES("36","","5","16");
INSERT INTO caja_nap_clientes VALUES("37","","5","17");
INSERT INTO caja_nap_clientes VALUES("38","","5","18");
INSERT INTO caja_nap_clientes VALUES("39","","5","19");
INSERT INTO caja_nap_clientes VALUES("40","","5","20");



DROP TABLE IF EXISTS clients;

CREATE TABLE `clients` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `surnames` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `documentid` bigint(20) NOT NULL,
  `document` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile_optional` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `reference` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `note` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `latitud` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `longitud` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint(20) NOT NULL DEFAULT 1,
  `net_router` int(11) NOT NULL,
  `net_name` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `net_password` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `net_localaddress` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `net_ip` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `nap_cliente_id` int(11) DEFAULT NULL,
  `ap_cliente_id` int(11) DEFAULT NULL,
  `zonaid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`),
  CONSTRAINT `clients_ibfk_1` FOREIGN KEY (`documentid`) REFERENCES `document_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO clients VALUES("1","IVAN","MENDEZ","2","92823759","9631035301","","","BARRIO PAJULULAR","SERCA DE LA IGLESIA DE SANTA CRUZ","","","","1","4","WALTER-JUNIOR-RENGIFO-ESPINOZA","pOjxQpT/vp7ZcrngOdsd5nZLckIyL2JjQURKZ0U0dVFSQkp1VFRKRWR6bnlmQkhwczF0Q2ZJVGJwMnc9","18.19.20.1","18.19.20.3","","1","2");
INSERT INTO clients VALUES("2","PRUEBA","PRUEBA P","2","45454545","969696969","","","SAN JUAN","PLAZA","OK","15.12653009035351","-91.81569952620707","1","5","PRUEBA-PRUEBA-P","d6xvGeynvQRSKIN+l7MMC3djajBJTDI4TkRVbktNR3RzSWwrT0Rob3V1ZStqbzRlWkVUNGtSZ1pWUjg9","192.168.10.1","192.168.10.2","1","","1");
INSERT INTO clients VALUES("3","WALTER JAVIER","RENGIFO ESPINOZA","2","75116541","999220735","972766166","ejemplo@gmail.com","DIRECCION DEL CLIENTE","REFRENCIA DEL DOMICILIO","MI PRIMO","-11.8549809","-77.0182917","1","5","WALTER-JAVIER-RENGIFO-ESPINOZA","OFv6Mu2iauO8y4geQad9ylQvZmM4aVcra3NxZmRzai9yeGtwT2NFd3gvYlJ3dW1CZXV0UU9YdThySjQ9","192.168.10.1","192.168.10.30","5","","");
INSERT INTO clients VALUES("4","JUAN","PEREZ SOTO","3","722794222","958956952","","juan@gmail.com","JR. JUAN","","SERVICIO PRO2025","-12.0356864","-76.9622016","1","5","JUAN-PEREZ-SOTO","2WK686h8hrAhMyNx+L3/fXpOWXR3cS9xWW9leHY0T3d1K2F2VEE9PQ==","","","","","");



DROP TABLE IF EXISTS contracts;

CREATE TABLE `contracts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `clientid` bigint(20) NOT NULL,
  `internal_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `payday` bigint(20) NOT NULL,
  `create_invoice` bigint(20) NOT NULL,
  `days_grace` bigint(20) NOT NULL,
  `discount` bigint(20) NOT NULL,
  `discount_price` decimal(12,2) NOT NULL,
  `months_discount` bigint(20) NOT NULL,
  `remaining_discount` bigint(20) NOT NULL,
  `contract_date` datetime NOT NULL,
  `suspension_date` date NOT NULL,
  `finish_date` date NOT NULL,
  `state` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `clientid` (`clientid`),
  CONSTRAINT `contracts_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contracts_ibfk_3` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO contracts VALUES("1","1","1","CT00001","1","","8","","0.00","","","2025-04-08 23:06:08","0000-00-00","0000-00-00","2");
INSERT INTO contracts VALUES("2","1","2","CT00002","21","","","","0.00","","","2025-04-20 06:53:22","0000-00-00","0000-00-00","2");
INSERT INTO contracts VALUES("3","1","3","CT00003","1","","5","","0.00","","","2025-04-20 13:29:14","2025-04-20","0000-00-00","3");
INSERT INTO contracts VALUES("4","1","4","CT00004","5","","5","","0.00","","","2025-05-04 12:24:11","2025-05-13","0000-00-00","4");



DROP TABLE IF EXISTS cronjobs;

CREATE TABLE `cronjobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `frequency` int(11) NOT NULL,
  `parm` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `parmdesc` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `parmx` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `lastrun` int(11) NOT NULL,
  `lastresult` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `code` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO cronjobs VALUES("1","Notificación de deuda, mismo dia de pago (API-WhatsApp)","1440","","","","1746378425","Ejecuci&oacute;n autom&aacute;tica exitosa","IN001","1");
INSERT INTO cronjobs VALUES("2","Notificación de deudas a todos los clientes (API-WhatsApp)\n","43200","","","","1737049735","Ejecuci&oacute;n autom&aacute;tica exitosa\n","IN002","1");
INSERT INTO cronjobs VALUES("3","Corte de servicio de las facturas vencidas (respetando dia de gracia y promesas)","1440","","","","1743718115","Prueba exitosa","IN003","");
INSERT INTO cronjobs VALUES("4","Envio masivo de deudas por correo electronico\n","21600","","","","1743718062","Prueba exitosa","CI001","");
INSERT INTO cronjobs VALUES("5","Backup base de datos","43200","","Días antes de expirar","%x% días después","1745068913","El backup ya existe!!!","IN004","1");



DROP TABLE IF EXISTS cronjobs_core;

CREATE TABLE `cronjobs_core` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lastrun` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO cronjobs_core VALUES("1","1742076842");



DROP TABLE IF EXISTS cronjobs_exceptions;

CREATE TABLE `cronjobs_exceptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cronjobid` int(11) NOT NULL,
  `clientid` int(11) NOT NULL,
  `param_name` varchar(64) NOT NULL,
  `param_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS cronjobs_history;

CREATE TABLE `cronjobs_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cronjobid` int(11) NOT NULL,
  `result` varchar(128) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO cronjobs_history VALUES("1","5","Backup generado!!!","1745068891");
INSERT INTO cronjobs_history VALUES("2","5","El backup ya existe!!!","1745068913");
INSERT INTO cronjobs_history VALUES("3","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1746378425");



DROP TABLE IF EXISTS currency;

CREATE TABLE `currency` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `currency_iso` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `language` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `currency_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `money` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `money_plural` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `symbol` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO currency VALUES("1","PES","ES","PESOS COLOMBIANOS","PESO","PESOS","$","2022-07-07 19:57:37","1");
INSERT INTO currency VALUES("2","PES","ES","PESOS MEXICANOS","PESOS","PESOS","MXN","2025-05-13 09:56:58","1");



DROP TABLE IF EXISTS departures;

CREATE TABLE `departures` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `billid` bigint(20) NOT NULL,
  `productid` bigint(20) NOT NULL,
  `departure_date` datetime NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `quantity_departures` bigint(20) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `total_cost` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `billid` (`billid`),
  KEY `productid` (`productid`),
  CONSTRAINT `departures_ibfk_1` FOREIGN KEY (`productid`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS detail_bills;

CREATE TABLE `detail_bills` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `billid` bigint(20) NOT NULL,
  `type` bigint(20) NOT NULL,
  `serproid` bigint(20) NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `quantity` bigint(20) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `billid` (`billid`),
  CONSTRAINT `detail_bills_ibfk_1` FOREIGN KEY (`billid`) REFERENCES `bills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO detail_bills VALUES("1","1","2","1","SERVICIO DE INTERNET HOGAR, MES DE ABRIL PRORRATEADO","1","35.00","35.00");
INSERT INTO detail_bills VALUES("2","2","1","","TARJETA DE RED","1","15.00","15.00");
INSERT INTO detail_bills VALUES("3","3","1","","PALE BOND","1","20.00","20.00");
INSERT INTO detail_bills VALUES("4","4","2","1","SERVICIO DE INTERNET HOGAR, MES DE MAYO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("5","5","2","1","SERVICIO DE INTERNET HOGAR, MES DE JUNIO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("6","6","2","1","SERVICIO DE INTERNET HOGAR, MES DE JULIO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("7","7","2","1","SERVICIO DE INTERNET HOGAR, MES DE AGOSTO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("10","8","2","1","SERVICIO DE INTERNET HOGAR, MES DE SEPTIEMBRE","1","50.00","50.00");
INSERT INTO detail_bills VALUES("11","9","2","1","SERVICIO DE INTERNET HOGAR, MES DE OCTUBRE","1","50.00","50.00");
INSERT INTO detail_bills VALUES("12","10","2","1","SERVICIO DE INTERNET HOGAR, MES DE NOVIEMBRE","1","50.00","50.00");
INSERT INTO detail_bills VALUES("13","11","1","","SERVICIO DE INSTALACIÓN","1","20.00","20.00");
INSERT INTO detail_bills VALUES("14","12","2","1","SERVICIO DE INTERNET HOGAR, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("15","13","2","1","SERVICIO DE INTERNET HOGAR, MES DE MAYO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("16","14","2","1","SERVICIO DE INTERNET HOGAR, MES DE JUNIO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("17","15","2","1","SERVICIO DE INTERNET HOGAR, MES DE JULIO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("18","16","2","1","SERVICIO DE INTERNET HOGAR, MES DE ABRIL PRORRATEADO","1","15.00","15.00");
INSERT INTO detail_bills VALUES("19","17","2","1","SERVICIO DE INTERNET HOGAR, MES DE MAYO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("20","18","2","1","SERVICIO DE INTERNET HOGAR, MES DE JUNIO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("21","19","2","1","SERVICIO DE INTERNET HOGAR, MES DE MAYO PRORRATEADO","1","42.00","42.00");
INSERT INTO detail_bills VALUES("22","20","2","1","SERVICIO DE INTERNET HOGAR, MES DE JUNIO","1","50.00","50.00");



DROP TABLE IF EXISTS detail_contracts;

CREATE TABLE `detail_contracts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `contractid` bigint(20) NOT NULL,
  `serviceid` bigint(20) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `contractid` (`contractid`),
  KEY `serviceid` (`serviceid`),
  CONSTRAINT `detail_contracts_ibfk_1` FOREIGN KEY (`contractid`) REFERENCES `contracts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_contracts_ibfk_2` FOREIGN KEY (`serviceid`) REFERENCES `services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO detail_contracts VALUES("1","1","1","50.00","2025-04-08 23:06:08","1");
INSERT INTO detail_contracts VALUES("2","2","1","50.00","2025-04-20 06:53:22","1");
INSERT INTO detail_contracts VALUES("3","3","1","50.00","2025-04-20 13:29:14","2");
INSERT INTO detail_contracts VALUES("4","4","1","50.00","2025-05-04 12:24:11","3");



DROP TABLE IF EXISTS detail_facility;

CREATE TABLE `detail_facility` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `facilityid` bigint(20) NOT NULL,
  `technicalid` bigint(20) NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `comment` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint(20) NOT NULL,
  `red_type` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facilityid` (`facilityid`),
  KEY `technicalid` (`technicalid`),
  CONSTRAINT `detail_facility_ibfk_1` FOREIGN KEY (`facilityid`) REFERENCES `facility` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_facility_ibfk_2` FOREIGN KEY (`technicalid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO detail_facility VALUES("1","1","1","2025-04-08 23:06:35","2025-04-08 23:06:55","CLIENTE NUEVO","1","2");
INSERT INTO detail_facility VALUES("2","2","1","2025-04-20 07:05:46","2025-04-20 07:06:27","","1","");
INSERT INTO detail_facility VALUES("3","3","1","2025-04-20 13:29:36","2025-04-20 13:29:57","CLIENTE NUEVO","1","2");
INSERT INTO detail_facility VALUES("4","4","1","2025-05-04 12:24:33","2025-05-04 12:25:03","SE REALIZO LA INSTALACIUON","1","");



DROP TABLE IF EXISTS document_type;

CREATE TABLE `document_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `document` varchar(100) NOT NULL,
  `maxlength` int(2) NOT NULL DEFAULT 8,
  `is_required` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

INSERT INTO document_type VALUES("1","SIN DOCUMENTO","8","");
INSERT INTO document_type VALUES("2","INE","8","1");
INSERT INTO document_type VALUES("3","SAT","11","1");
INSERT INTO document_type VALUES("4","CARNET DE EXTRANJERIA","20","");
INSERT INTO document_type VALUES("5","PASAPORTE","20","");



DROP TABLE IF EXISTS emails;

CREATE TABLE `emails` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clientid` bigint(20) NOT NULL,
  `billid` bigint(20) NOT NULL,
  `affair` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `sender` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `files` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `type_file` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `template_email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `billid` (`billid`),
  CONSTRAINT `emails_ibfk_1` FOREIGN KEY (`billid`) REFERENCES `bills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `emails_ibfk_2` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS facility;

CREATE TABLE `facility` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clientid` bigint(20) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `technical` bigint(20) NOT NULL,
  `attention_date` datetime NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `cost` decimal(12,2) NOT NULL,
  `detail` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL DEFAULT 2,
  PRIMARY KEY (`id`),
  KEY `technicalid` (`userid`),
  KEY `clientid` (`clientid`),
  CONSTRAINT `facility_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `facility_ibfk_3` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO facility VALUES("1","1","1","1","2025-04-08 23:04:00","2025-04-08 23:06:35","2025-04-08 23:06:55","0.00","","2025-04-08 23:06:08","1");
INSERT INTO facility VALUES("2","2","1","1","2025-04-20 06:49:00","2025-04-20 07:05:46","2025-04-20 07:06:27","20.00","Ok","2025-04-20 06:53:22","1");
INSERT INTO facility VALUES("3","3","1","1","2025-04-20 13:26:00","2025-04-20 13:29:36","2025-04-20 13:29:57","0.00","","2025-04-20 13:29:14","1");
INSERT INTO facility VALUES("4","4","1","1","2025-05-04 12:11:00","2025-05-04 12:24:33","2025-05-04 12:25:03","0.00","se instalo correctamente con todos los procedimientos.","2025-05-04 12:24:11","1");



DROP TABLE IF EXISTS forms_payment;

CREATE TABLE `forms_payment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO forms_payment VALUES("1","EFECTIVO","2022-07-07 21:50:55","1");
INSERT INTO forms_payment VALUES("2","TRASNFERENCIA BANCARIA","2024-10-24 19:32:46","1");



DROP TABLE IF EXISTS gallery_images;

CREATE TABLE `gallery_images` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clientid` bigint(20) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `type` bigint(20) NOT NULL,
  `typeid` bigint(20) NOT NULL,
  `registration_date` datetime NOT NULL,
  `image` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO gallery_images VALUES("1","1","1","3","","2025-04-08 23:13:46","walter_junior_rengifo_espinoza_277755b5375d1bd09c46b56654f16a4d.png");
INSERT INTO gallery_images VALUES("2","1","1","3","","2025-04-12 06:15:40","walter_junior_rengifo_espinoza_6d929fb39e3fbd97ebd2bbb56b39e0c7.jpeg");
INSERT INTO gallery_images VALUES("4","2","1","3","","2025-04-20 07:12:32","prueba_prueba_p_25ce65d37ea7e4698a1126867101d7a3.jpeg");
INSERT INTO gallery_images VALUES("5","4","1","1","4","2025-05-04 12:25:00","juan_perez_soto_1a7584dde122ea0c67850ecc42ea3f3b.jpg");



DROP TABLE IF EXISTS incidents;

CREATE TABLE `incidents` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `incident` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO incidents VALUES("1","SIN INTERNET","2025-04-08 23:13:02","1");
INSERT INTO incidents VALUES("2","INTERNET LENTO","2025-05-13 09:58:06","1");



DROP TABLE IF EXISTS income;

CREATE TABLE `income` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `productid` bigint(20) NOT NULL,
  `income_date` datetime NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `quantity_income` bigint(20) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `total_cost` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `productid` (`productid`),
  CONSTRAINT `income_ibfk_1` FOREIGN KEY (`productid`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO income VALUES("1","1","2025-04-19 08:13:03","COMPRA DE PRODUCTO (MEDIANTE REGISTRO)","10","10.00","100.00");



DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `module` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO modules VALUES("1","Dashboard","1");
INSERT INTO modules VALUES("2","Clientes","1");
INSERT INTO modules VALUES("3","Usuarios","1");
INSERT INTO modules VALUES("4","Tickets","1");
INSERT INTO modules VALUES("5","Incidencias","1");
INSERT INTO modules VALUES("6","Facturas","1");
INSERT INTO modules VALUES("7","Productos","1");
INSERT INTO modules VALUES("8","Categorias","1");
INSERT INTO modules VALUES("9","Proveedores","1");
INSERT INTO modules VALUES("10","Pagos","1");
INSERT INTO modules VALUES("11","Servicios","1");
INSERT INTO modules VALUES("12","Empresa","1");
INSERT INTO modules VALUES("13","Instalaciones","1");
INSERT INTO modules VALUES("14","Divisas","1");
INSERT INTO modules VALUES("15","Formas de pago","1");
INSERT INTO modules VALUES("16","Comprobantes","1");
INSERT INTO modules VALUES("17","Unidades","1");
INSERT INTO modules VALUES("18","Correos","1");
INSERT INTO modules VALUES("19","Gestión de Red","1");
INSERT INTO modules VALUES("20","Campaña","1");



DROP TABLE IF EXISTS network_routers;

CREATE TABLE `network_routers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ip` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `port` int(11) NOT NULL,
  `username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `password` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ip_range` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `zoneid` int(11) NOT NULL,
  `identity` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `board_name` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `version` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `status` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO network_routers VALUES("4","CCR600","146.190.163.73","8888","wispprored","rhvLe0wvhUJvV4QU3tTm33FYWnVIMXR2anBwY1dwT1NtUjhQbVE9PQ==","10.20.10.1/24","1","","","","");
INSERT INTO network_routers VALUES("5","Hhh","146.190.61.104","80","wispprored","T2WAQhx+Bsd0/q24GGWNYGpRRmdWM2VWYy9xMVN0Z1FuTXBTbFE9PQ==","192.168.10.2/24","1","","","","");



DROP TABLE IF EXISTS network_zones;

CREATE TABLE `network_zones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `mode` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO network_zones VALUES("1","PPPoE","2");
INSERT INTO network_zones VALUES("2","Simple Queues","1");



DROP TABLE IF EXISTS otros_ingresos;

CREATE TABLE `otros_ingresos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` enum('INGRESO','EGRESO') NOT NULL,
  `fecha` date DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `monto` decimal(12,2) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `state` enum('NORMAL','PENDIENTE','PAGADO') NOT NULL DEFAULT 'NORMAL',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




DROP TABLE IF EXISTS p_campos;

CREATE TABLE `p_campos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `obligatorio` tinyint(1) DEFAULT NULL,
  `tablaId` int(11) DEFAULT NULL,
  `tipo` varchar(100) DEFAULT NULL,
  `campo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




DROP TABLE IF EXISTS p_tabla;

CREATE TABLE `p_tabla` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `tabla` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO p_tabla VALUES("1","Ap Clientes","ap_clientes");
INSERT INTO p_tabla VALUES("2","Ap Emisor","ap_emisor");
INSERT INTO p_tabla VALUES("3","Ap Receptor","ap_receptor");



DROP TABLE IF EXISTS payments;

CREATE TABLE `payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `billid` bigint(20) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `clientid` bigint(20) NOT NULL,
  `internal_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `paytypeid` bigint(20) NOT NULL,
  `payment_date` datetime NOT NULL,
  `comment` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL,
  `amount_total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `remaining_credit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `state` bigint(20) NOT NULL DEFAULT 1,
  `ticket_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `reference_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `billid` (`billid`),
  KEY `clientid` (`clientid`),
  KEY `userid` (`userid`),
  KEY `paytypeid` (`paytypeid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO payments VALUES("1","2","1","1","T00001","1","2025-04-08 23:14:24","","0.00","15.00","15.00","","","");
INSERT INTO payments VALUES("2","1","1","1","T00002","1","2025-04-08 23:15:00","","35.00","35.00","0.00","1","","");
INSERT INTO payments VALUES("3","3","1","1","T00003","1","2025-04-08 23:22:00","","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("4","4","1","1","T00004","1","2025-04-08 23:24:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("5","5","1","1","T00005","1","2025-04-08 23:26:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("6","6","1","1","T00006","1","2025-04-08 23:27:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("7","7","1","1","T00007","1","2025-04-08 23:28:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("8","8","1","1","T00008","1","2025-04-09 10:36:00","","50.00","50.00","0.00","2","","");
INSERT INTO payments VALUES("9","8","1","1","T00009","1","2025-04-09 10:36:00","","50.00","50.00","0.00","2","","");
INSERT INTO payments VALUES("10","8","1","1","T00010","1","2025-04-10 19:34:00","","10.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("11","11","1","2","T00011","2","2025-04-20 07:22:00","","20.00","20.00","0.00","1","","");
INSERT INTO payments VALUES("12","12","1","2","T00012","1","2025-04-20 07:25:00","","10.00","10.00","0.00","1","","");
INSERT INTO payments VALUES("13","13","1","2","T00013","1","2025-04-20 07:25:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("14","8","1","1","T00014","1","2025-04-20 07:31:00","","40.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("15","14","1","2","T00015","1","2025-04-20 07:42:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("16","16","1","3","T00016","1","2025-04-20 13:30:00","","15.00","15.00","0.00","1","","");
INSERT INTO payments VALUES("17","17","1","3","T00017","1","2025-04-20 13:31:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("18","18","1","3","T00018","1","2025-04-20 13:31:00","","10.00","50.00","0.00","1","","");



DROP TABLE IF EXISTS permits;

CREATE TABLE `permits` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `profileid` bigint(20) NOT NULL,
  `moduleid` bigint(20) NOT NULL,
  `r` bigint(20) NOT NULL,
  `a` bigint(20) NOT NULL,
  `e` bigint(20) NOT NULL,
  `v` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `profileid` (`profileid`),
  KEY `moduleid` (`moduleid`)
) ENGINE=InnoDB AUTO_INCREMENT=296 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO permits VALUES("19","2","1","","","","1");
INSERT INTO permits VALUES("20","2","2","1","","","1");
INSERT INTO permits VALUES("21","2","3","","","","");
INSERT INTO permits VALUES("22","2","4","1","1","","1");
INSERT INTO permits VALUES("23","2","5","","","","");
INSERT INTO permits VALUES("24","2","6","","","","");
INSERT INTO permits VALUES("25","2","7","","","","");
INSERT INTO permits VALUES("26","2","8","","","","");
INSERT INTO permits VALUES("27","2","9","","","","");
INSERT INTO permits VALUES("28","2","10","1","","","1");
INSERT INTO permits VALUES("29","2","11","","","","");
INSERT INTO permits VALUES("30","2","12","","","","");
INSERT INTO permits VALUES("31","2","13","1","1","","1");
INSERT INTO permits VALUES("32","2","14","","","","");
INSERT INTO permits VALUES("33","2","15","","","","");
INSERT INTO permits VALUES("34","2","16","","","","");
INSERT INTO permits VALUES("35","2","17","","","","");
INSERT INTO permits VALUES("36","2","18","","","","");
INSERT INTO permits VALUES("199","3","1","1","","1","1");
INSERT INTO permits VALUES("200","3","2","1","1","","1");
INSERT INTO permits VALUES("201","3","3","1","","","1");
INSERT INTO permits VALUES("202","3","4","1","1","","1");
INSERT INTO permits VALUES("203","3","5","1","","","1");
INSERT INTO permits VALUES("204","3","6","1","","","1");
INSERT INTO permits VALUES("205","3","7","1","","","1");
INSERT INTO permits VALUES("206","3","8","1","","","1");
INSERT INTO permits VALUES("207","3","9","1","","","1");
INSERT INTO permits VALUES("208","3","10","1","","","1");
INSERT INTO permits VALUES("209","3","11","1","","","1");
INSERT INTO permits VALUES("210","3","12","1","","","1");
INSERT INTO permits VALUES("211","3","13","1","1","1","1");
INSERT INTO permits VALUES("212","3","14","1","","","1");
INSERT INTO permits VALUES("213","3","15","1","","","1");
INSERT INTO permits VALUES("214","3","16","1","","","1");
INSERT INTO permits VALUES("215","3","17","1","","","1");
INSERT INTO permits VALUES("216","3","18","1","","","1");
INSERT INTO permits VALUES("276","1","1","1","1","1","1");
INSERT INTO permits VALUES("277","1","2","1","1","1","1");
INSERT INTO permits VALUES("278","1","3","1","1","1","1");
INSERT INTO permits VALUES("279","1","4","1","1","1","1");
INSERT INTO permits VALUES("280","1","5","1","1","1","1");
INSERT INTO permits VALUES("281","1","6","1","1","1","1");
INSERT INTO permits VALUES("282","1","7","1","1","1","1");
INSERT INTO permits VALUES("283","1","8","1","1","1","1");
INSERT INTO permits VALUES("284","1","9","1","1","1","1");
INSERT INTO permits VALUES("285","1","10","1","1","1","1");
INSERT INTO permits VALUES("286","1","11","1","1","1","1");
INSERT INTO permits VALUES("287","1","12","1","1","1","1");
INSERT INTO permits VALUES("288","1","13","1","1","1","1");
INSERT INTO permits VALUES("289","1","14","1","1","1","1");
INSERT INTO permits VALUES("290","1","15","1","1","1","1");
INSERT INTO permits VALUES("291","1","16","1","1","1","1");
INSERT INTO permits VALUES("292","1","17","1","1","1","1");
INSERT INTO permits VALUES("293","1","18","1","1","1","1");
INSERT INTO permits VALUES("294","1","19","1","1","1","1");
INSERT INTO permits VALUES("295","1","20","1","1","1","1");



DROP TABLE IF EXISTS product_category;

CREATE TABLE `product_category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO product_category VALUES("1","EJEMPLO","","2025-04-19 08:12:22","1");



DROP TABLE IF EXISTS products;

CREATE TABLE `products` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `internal_code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `barcode` varchar(13) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `product` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `model` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `brand` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `extra_info` bigint(20) NOT NULL,
  `serial_number` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mac` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `sale_price` decimal(12,2) NOT NULL,
  `purchase_price` decimal(12,2) NOT NULL,
  `stock` bigint(20) NOT NULL,
  `stock_alert` bigint(20) NOT NULL,
  `categoryid` bigint(20) NOT NULL,
  `unitid` bigint(20) NOT NULL,
  `providerid` bigint(20) NOT NULL,
  `image` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `categoryid` (`categoryid`),
  KEY `unitid` (`unitid`),
  KEY `providerid` (`providerid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO products VALUES("1","P00001","23232","DATA","DSDAS","","","","","","20.00","10.00","10","1","1","1","1","no_image.jpg","2025-04-19 08:13:03");



DROP TABLE IF EXISTS profiles;

CREATE TABLE `profiles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `profile` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `description` varchar(300) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO profiles VALUES("1","ADMINISTRADOR","ACCESOS A TODOS LOS MODULOS","2022-07-07 15:51:53","1");
INSERT INTO profiles VALUES("2","TECNICO","CLIENTES, TICKET Y COBRANZA, CON RESTRICCIONES","2022-07-07 15:51:53","1");
INSERT INTO profiles VALUES("3","COBRANZA","COBRANZA DE FACTURAS PENDIENTES","2022-07-07 15:51:53","1");



DROP TABLE IF EXISTS providers;

CREATE TABLE `providers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `provider` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `documentid` bigint(20) NOT NULL,
  `document` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO providers VALUES("1","DATA","1","32323232","432432423","","","2025-04-19 08:12:35","1");



DROP TABLE IF EXISTS services;

CREATE TABLE `services` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `internal_code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `service` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `type` bigint(20) NOT NULL,
  `rise` bigint(20) NOT NULL,
  `rise_type` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `descent` bigint(20) NOT NULL,
  `descent_type` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `details` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `routers` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO services VALUES("1","S00001","INTERNET HOGAR","1","2","MBPS","5","MBPS","50.00","","","2025-04-08 23:05:43","1");



DROP TABLE IF EXISTS ticket_solution;

CREATE TABLE `ticket_solution` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticketid` bigint(20) NOT NULL,
  `technicalid` bigint(20) NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `comment` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticketid` (`ticketid`),
  KEY `technicalid` (`technicalid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO ticket_solution VALUES("1","1","1","2025-04-08 23:13:35","2025-04-20 07:20:42","OK","1");
INSERT INTO ticket_solution VALUES("2","4","1","2025-04-20 13:37:58","2025-04-20 13:38:04","SDSDSDSADS","1");



DROP TABLE IF EXISTS tickets;

CREATE TABLE `tickets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `clientid` bigint(20) NOT NULL,
  `technical` bigint(20) NOT NULL,
  `incidentsid` bigint(20) NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `priority` bigint(20) NOT NULL,
  `attention_date` datetime NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL DEFAULT 2,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `clientid` (`clientid`),
  KEY `incidentsid` (`incidentsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO tickets VALUES("1","1","1","1","1","TICKET NUEVO","1","2025-04-08 23:13:00","2025-04-08 23:13:35","2025-04-20 07:20:42","2025-04-08 23:13:18","1");
INSERT INTO tickets VALUES("2","1","2","","1","OK","1","2025-04-20 07:12:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-20 07:12:13","5");
INSERT INTO tickets VALUES("3","1","1","","1","","3","2025-04-20 07:19:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-20 07:19:58","5");
INSERT INTO tickets VALUES("4","1","3","1","1","hola no tengo internet amigo adolfo","2","2025-04-20 15:36:00","2025-04-20 13:37:58","2025-04-20 13:38:04","2025-04-20 13:37:20","1");
INSERT INTO tickets VALUES("5","1","1","","1","","1","2025-04-26 10:00:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-26 10:01:08","5");



DROP TABLE IF EXISTS tools;

CREATE TABLE `tools` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `facilityid` bigint(20) NOT NULL,
  `productid` bigint(20) NOT NULL,
  `quantity` bigint(20) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `product_condition` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `serie` varchar(150) DEFAULT NULL,
  `mac` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facilityid` (`facilityid`),
  KEY `productid` (`productid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS unit;

CREATE TABLE `unit` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `united` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO unit VALUES("1","UN","UNIDAD","2022-07-07 21:03:40","1");



DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `surnames` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `documentid` bigint(20) NOT NULL,
  `document` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `email` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `profileid` bigint(20) NOT NULL,
  `username` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `token` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `image` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`),
  KEY `profileid` (`profileid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO users VALUES("1","PABLO","LOPEZ","2","04801044274","9631046633","plmt20a@gmail.com","1","admin","SGl1ZVJCaENCazZVVFcyc2hIaFhHUT09","","profile_c85c5b3238b1d832cd5d35a299b11077.jpeg","2022-07-07 19:39:22","1");



DROP TABLE IF EXISTS voucher_series;

CREATE TABLE `voucher_series` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `serie` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `fromc` bigint(20) NOT NULL,
  `until` bigint(20) NOT NULL,
  `voucherid` bigint(20) NOT NULL,
  `available` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `voucherid` (`voucherid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO voucher_series VALUES("1","2022-07-07","R001","1","1000000","1","999980");



DROP TABLE IF EXISTS vouchers;

CREATE TABLE `vouchers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `voucher` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO vouchers VALUES("1","RECIBO","2022-07-07 17:37:14","1");



DROP TABLE IF EXISTS zonas;

CREATE TABLE `zonas` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nombre_zona` varchar(500) NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

INSERT INTO zonas VALUES("1","BOLIVIA","2025-04-09 16:09:42","1");
INSERT INTO zonas VALUES("2","PERU","2025-04-09 16:09:46","1");
INSERT INTO zonas VALUES("3","CHILE","2025-04-09 16:09:49","1");



SET FOREIGN_KEY_CHECKS=1;